class base_master_sequence extends uvm_sequence #(master_seq_item);
  `uvm_object_utils (base_master_sequence)

  uvm_phase         phase;
  cdma_reg_block    reg_block;
  uvm_status_e      status;
  uvm_reg_data_t    cdmasr_data;
  uvm_reg_data_t    cdmacr_data;
  master_seq_item   pkt;
  config_obj        obj;

  function new (string name = "base_master_sequence");
     super.new (name);
  endfunction

    task pre_body();
        phase   =   get_starting_phase();
        if(phase != null) begin
            phase.raise_objection(this);
            `uvm_info(get_full_name(),"inside_pre_body", UVM_MEDIUM)
        end
    endtask
    task post_body();
        if(phase != null) begin
            `uvm_info(get_full_name(),"inside_post_body", UVM_MEDIUM)
            phase.drop_objection(this);
        end
    endtask

  task body ();
    `uvm_info(get_full_name(),"inside base_master_sequence body", UVM_MEDIUM)
    //if (!uvm_config_db #(config_obj)::get(this,"","config_obj",obj))
    //    `uvm_fatal (get_full_name(),"config_obj get FAILED,check if set")

    reg_block = cdma_reg_block::type_id::create("reg_block");
    //if(!uvm_config_db#(cdma_reg_block)::get(uvm_root::get(),"","reg_block",reg_block))begin
    //  `uvm_fatal("SEQ", "Register model not found in config_db!")
    //end
  endtask:body

  extern task write_info    (master_type master_sel,slave_type slave_sel,burst_type_t burst_sel,int size,len, cache_t cache);
  extern task read_info 	(master_type master_sel,slave_type slave_sel,burst_type_t burst_sel,int size,len, cache_t cache);
endclass: base_master_sequence


task base_master_sequence:: write_info (master_type master_sel, slave_type slave_sel,burst_type_t burst_sel,int size,len,cache_t cache);
  //master_seq_item pkt = master_seq_item :: type_id :: create ("pkt");
  repeat(4)begin
    master_seq_item pkt = master_seq_item :: type_id :: create ("pkt");
    start_item (pkt); 
    assert (pkt.randomize()with{pkt.operation==WRITE;
				//pkt.awid  == wid;
                //pkt.awaddr== addr;
 				pkt.master  == master_sel;
 				pkt.slave   == slave_sel;
                            pkt.awburst==burst_sel;
                            pkt.awsize==size;
                            pkt.awlen==len;
                            pkt.awcache== cache;
                            pkt.awlock== 0; pkt.awqos== 0; pkt.awprot== 0;pkt.awregion==0;
                            //pkt.resp_ready_dly== 0;pkt.cmd2cmd_dly== 0;pkt.add2data_dly== 0;
                            })
    else `uvm_error (get_full_name(),"pkt randomization failed")
    `uvm_info(get_full_name(),pkt.sprint(),UVM_MEDIUM)
    finish_item(pkt);
    get_response(pkt);
  end
endtask:write_info

task base_master_sequence:: read_info (master_type master_sel,slave_type slave_sel,burst_type_t burst_sel,int size,len, cache_t cache);
  master_seq_item pkt = master_seq_item :: type_id :: create ("pkt");
  repeat(4)begin
    start_item(pkt);
    assert (pkt.randomize()with{pkt.operation== READ;
                                //pkt.arid   == rid;
                                //pkt.araddr == addr;
 				pkt.master  == master_sel;
 				pkt.slave   == slave_sel;
                             pkt.arburst== burst_sel;
                             pkt.arsize == size;
                             pkt.arlen  == len;
                             pkt.arcache== cache;
                             pkt.arlock==0; pkt.arqos==0; pkt.arprot==0;pkt.arregion==0;
                             //pkt.add_valid_dly==0;pkt.resp_ready_dly==0;pkt.cmd2cmd_dly==0;
                             //pkt.add2data_dly==0;pkt.write_valid2valid_dly[0] ==0;
                             })
    else `uvm_error (get_full_name(), "randomization failed")
    `uvm_info(get_full_name(),pkt.sprint(),UVM_MEDIUM)
    finish_item (pkt);
    get_response(pkt);
  end
endtask: read_info


class reg_access_seq extends base_master_sequence;
  `uvm_object_utils (reg_access_seq) 
  function new (string name = "reg_access_seq");
    super.new (name); 
  endfunction

  master_seq_item pkt;
    
  task body();
    `uvm_info(get_full_name(), "inside_reg_access_seq body", UVM_MEDIUM)
    for (int i = 0; i <= 40; i += 4) begin
        pkt = master_seq_item::type_id::create("pkt");
        //`uvm_do_with(pkt, {
        start_item(pkt);
        if(!pkt.randomize() with {
            pkt.operation == READ;
            pkt.araddr    == i;
        
            pkt.awaddr    == 'h0;
            pkt.bresp     == 'h0;
        })begin
        `uvm_error (get_full_name(), "randomization_failed")
        end
        finish_item(pkt);
        $display("%0t: the_seq_addr : %h",$time,pkt.araddr);
    end
  endtask: body
endclass : reg_access_seq


class reg_write_read_seq extends base_master_sequence;
  `uvm_object_utils (reg_write_read_seq) 
  function new (string name = "reg_write_read_seq");
    super.new (name); 
  endfunction

  master_seq_item pkt;
    
  task body();
    `uvm_info(get_full_name(), "inside_reg_access_seq body", UVM_MEDIUM)
    for (int i = 0; i <= 40; i += 4) begin
        pkt = master_seq_item::type_id::create("pkt");
        start_item(pkt);
        if(!pkt.randomize() with {
            pkt.operation == WRITE;
            pkt.awaddr    == i;
            pkt.wdata.size() == 1;
            pkt.wdata[0]  == 'h123;
 
            pkt.araddr    == 'h0;
            pkt.rresp[0]  == 'h0;
        })begin
        `uvm_error (get_full_name(), "randomization_failed")
        end
        finish_item(pkt);
        get_response(pkt);
        $display("%0t: the_seq_addr : %h",$time,pkt.awaddr);
    end
    for (int i = 0; i <= 40; i += 4) begin
        pkt = master_seq_item::type_id::create("pkt");
        start_item(pkt);
        if(!pkt.randomize() with {
            pkt.operation == READ;
            pkt.araddr    == i;
        
            pkt.awaddr    == 'h0;
            //pkt.wdata[0]  == 'h0;
            pkt.bresp[0]  == 'h0;
        })begin
        `uvm_error (get_full_name(), "randomization_failed")
        end
        finish_item(pkt);
        get_response(pkt);
        $display("%0t: the_seq_addr : %h",$time,pkt.awaddr);
    end
  endtask: body
endclass : reg_write_read_seq

class cdma_config_seq extends base_master_sequence;
  `uvm_object_utils(cdma_config_seq)
  
  function new(string name = "cdma_config_seq");
    super.new(name); 
  endfunction

  master_seq_item pkt;

  task body();
    // CDMACR WRITE
    pkt = master_seq_item::type_id::create("cr_pkt");
    start_item(pkt);
    if(!pkt.randomize() with {
        pkt.operation == WRITE;
        pkt.awaddr    == 'h00;
        pkt.wdata.size() == 1;
        pkt.wdata[0]  == 'h0000_A000;

        pkt.araddr    == 'h0;
        pkt.rdata[0]  == 'h0;
        pkt.rresp[0]  == 'h0;
    })begin
        `uvm_error (get_full_name(), "randomization_failed")
    end
    finish_item(pkt);

    // CDMACR READ
    pkt = master_seq_item::type_id::create("cr_pkt");
    start_item(pkt);
    if(!pkt.randomize() with {
        pkt.operation == READ;
        pkt.araddr    == 'h00;

        pkt.awaddr    == 'h0;
        pkt.wdata[0]  == 'h0;
        pkt.bresp[0]  == 'h0;
    })begin
        `uvm_error (get_full_name(), "randomization_failed")
    end
    finish_item(pkt);

    // Source Address
    pkt = master_seq_item::type_id::create("sa_pkt");
    start_item(pkt);
    if(!pkt.randomize() with {
        pkt.operation == WRITE;
        pkt.awaddr    == 'h18;
        pkt.wdata.size() == 1;
        pkt.wdata[0]  == 'h1000;

        pkt.araddr    == 'h0;
        pkt.rdata[0]  == 'h0;
        pkt.rresp[0]  == 'h0;
    })begin
        `uvm_error (get_full_name(), "randomization_failed")
    end
    finish_item(pkt);
    //get_response(pkt);

    // Destination Address
    pkt = master_seq_item::type_id::create("da_pkt");
    start_item(pkt);
    if(!pkt.randomize() with {
        pkt.operation == WRITE;
        pkt.awaddr    == 'h20;
        pkt.wdata.size() == 1;
        pkt.wdata[0]  == 'h2000;

        pkt.araddr    == 'h0;
        pkt.rdata[0]  == 'h0;
        pkt.rresp[0]  == 'h0;
    })begin
        `uvm_error (get_full_name(), "randomization_failed")
    end
    finish_item(pkt);
    //get_response(pkt);

    // Bytes to Transfer (starts DMA)
    pkt = master_seq_item::type_id::create("btt_pkt");
    start_item(pkt);
    if(!pkt.randomize() with {
        pkt.operation == WRITE;
        pkt.awaddr    == 'h28;
        pkt.wdata.size() == 1;
        pkt.wdata[0]  == 10;

        pkt.araddr    == 'h0;
        pkt.rdata[0]  == 'h0;
        pkt.rresp[0]  == 'h0;
    })begin
        `uvm_error (get_full_name(), "randomization_failed")
    end
    finish_item(pkt);
    //get_response(pkt);
  endtask
endclass


class simple_mode_wr_rd_seq extends base_master_sequence;
    `uvm_object_utils(simple_mode_wr_rd_seq)
  
    cdma_reg_block  reg_block;
    uvm_status_e    status;
    uvm_reg_data_t  cdmasr_data;
    uvm_reg_data_t  cdmacr_data;
    master_seq_item pkt;
    
    function new(string name = "simple_mode_wr_rd_seq");
        super.new(name); 
    endfunction
    
    task body();
        super.body();

        if(!uvm_config_db #(config_obj) :: get(null, "", "config_obj", obj))
            `uvm_fatal (get_full_name(), "config_db_not_accessable");

        if(!uvm_config_db#(cdma_reg_block)::get(null,get_full_name(),"reg_block",reg_block)) begin
            `uvm_fatal("SEQ", "Could not find cdma_reg_block in config_db!")
        end

        `uvm_info("SIMPLE_MODE_INCR_SEQ", "Starting Simple Mode INCR Transfer Sequence", UVM_LOW)
        //reg_block.cdmasr.read(status, cdmasr_data);
        //`uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Read SR: %0h", cdmasr_data), UVM_LOW)
        
        pkt = master_seq_item::type_id::create("btt_pkt");
        if(!pkt.randomize() with {pkt.btt_s==MED;})begin
            `uvm_error (get_full_name(), "randomization_failed")
        end

        do begin
            reg_block.cdmasr.read(status, cdmasr_data);
	    end while(cdmasr_data[1] == 0);
        `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Idle = %0h - wait clear",cdmasr_data[1]), UVM_LOW)

        `uvm_info("SIMPLE_MODE_INCR_SEQ", "Writing to registers", UVM_LOW)
        reg_block.cdmacr.write(status, 32'h5000);
        reg_block.cdmacr.read(status, cdmacr_data);
        `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Read CR: 0x%0h", cdmacr_data), UVM_LOW)
        reg_block.sa.write(status, pkt.sa_addr);
        reg_block.da.write(status, pkt.da_addr);
        reg_block.btt.write(status, pkt.btt_bytes);
        //reg_block.sa.write(status, 32'h1000);
        //reg_block.da.write(status, 32'h2000);
        //reg_block.btt.write(status, 32'h100);
        //reg_block.sa.write(status, 'd30);
        //reg_block.da.write(status, 'd25);
        //reg_block.btt.write(status, 'd5);
        `uvm_info("SIMPLE_MODE_INCR_SEQ", "BTT written - Seq starts", UVM_LOW)

        reg_block.cdmasr.read(status, cdmasr_data);
        `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Idle = %0h - Waiting for idle",cdmasr_data[1]), UVM_LOW)
        //do begin
        //    reg_block.cdmasr.read(status, cdmasr_data);
	    //end while(cdmasr_data[1] == 0);

        `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("cdma_introut: %0h", obj.mas_if[0].cdma_introut), UVM_LOW)
        wait(obj.mas_if[0].cdma_introut);
        `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("cdma_introut: %0h", obj.mas_if[0].cdma_introut), UVM_LOW)
        reg_block.cdmasr.read(status, cdmasr_data);

        `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Idle = %0h - transfer complete, wait clear",cdmasr_data[1]), UVM_LOW)
        `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Read SR: 0x%0h", cdmasr_data), UVM_LOW)
        
	    if(cdmasr_data[12] == 1)begin
            reg_block.cdmasr.write(status, 32'h1000);
            `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Read SR IOC[12]: %0h", cdmasr_data[12]), UVM_LOW)
		end else
		    `uvm_error("SIMPLE_MODE_INCR_SEQ","IOC bit is low")

	    if(cdmasr_data[14] == 1)begin
            reg_block.cdmasr.write(status, 32'h4000);
            `uvm_info("SIMPLE_MODE_INCR_SEQ", $sformatf("Read SR ERR[14]: %0h", cdmasr_data[14]), UVM_LOW)
            `uvm_error("SIMPLE_MODE_INCR_SEQ", "ERR bit is high", UVM_LOW)
		end
    endtask
endclass: simple_mode_wr_rd_seq


class simple_mode_fixed_seq extends base_master_sequence;
    `uvm_object_utils(simple_mode_fixed_seq)

    function new(string name = "simple_mode_fixed_seq");
        super.new(name); 
    endfunction
    
    task body();
        super.body();
        if(!uvm_config_db#(cdma_reg_block)::get(null,get_full_name(),"reg_block",reg_block)) begin
            `uvm_fatal("SEQ", "Could not find cdma_reg_block in config_db!")
        end

        pkt = master_seq_item::type_id::create("pkt");
        if(!pkt.randomize() with {pkt.btt_s==MIN;})begin
            `uvm_error (get_full_name(), "randomization_failed")
        end

        `uvm_info("SIMPLE_MODE_FIXED_SEQ", "Starting Simple Mode Fixed Transfer Sequence", UVM_LOW)
        do begin
            reg_block.cdmasr.read(status,cdmasr_data);
        end while(cdmasr_data[1]==0);
        `uvm_info("SIMPLE_MODE_FIXED_SEQ", $sformatf("Idle = %0h - wait cleared",cdmasr_data[1]), UVM_LOW)
        `uvm_info("SIMPLE_MODE_FIXED_SEQ", "Configuring CDMACR in Key Hole Read Mode", UVM_LOW)
        reg_block.cdmacr.write(status,32'h5010);
        reg_block.cdmacr.read(status,cdmacr_data);
        `uvm_info("SIMPLE_MODE_FIXED_SEQ", $sformatf("CDMACR Key Hole Mode: Write:%0h | Read:%0h",cdmacr_data[5],cdmacr_data[4]), UVM_LOW)
        `uvm_info("SIMPLE_MODE_FIXED_SEQ", "Configuring Registers SA, DA, BTT", UVM_LOW)
        reg_block.sa.write(status,pkt.sa_addr);
        reg_block.da.write(status,pkt.da_addr);
        reg_block.btt.write(status,pkt.btt_bytes);
        `uvm_info("SIMPLE_MODE_FIXED_SEQ", $sformatf("Configured BTT: %0d - Transfer started!",pkt.btt_bytes), UVM_LOW)
        do begin
            reg_block.cdmasr.read(status,cdmasr_data);
        end while(cdmasr_data[1]==0);
        `uvm_info("SIMPLE_MODE_FIXED_SEQ", $sformatf("Idle = %0h - wait cleared. Transfer completed!",cdmasr_data[1]), UVM_LOW)

        if(cdmasr_data[14]||cdmasr_data[12] == 1) begin
            if(cdmasr_data[12]) begin
                reg_block.cdmasr.write(status,32'h1000);
                `uvm_info("SIMPLE_MODE_FIXED_SEQ", "IOC_Irq asserted", UVM_LOW)
            end
            if(cdmasr_data[14]) begin
                reg_block.cdmasr.write(status,32'h4000);
                `uvm_error("SIMPLE_MODE_FIXED_SEQ", "Err_Irq asserted", UVM_LOW)
            end
        end
    endtask
endclass



















































































































































///* ************ m0 to all the slave (single master single slave)************* */
//class access_seq_m0_s0 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m0_s0) 
//  function new (string name = "access_seq_m0_s0");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    //write_info (m0,s0,INCR,3,10,0);		//255
//    read_info  (m0,s0,INCR,3,8,0);
//  endtask: body
//endclass : access_seq_m0_s0
//
//
//class access_seq_m0_s1 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m0_s1) 
//  function new (string name = "access_seq_m0_s1");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    //write_info (m0,s1,INCR,3,7,0);		//slave 0,size=4,len=2
//    read_info  (m0,s1,INCR,3,25,0);
//  endtask: body
//endclass : access_seq_m0_s1
//
//
//class access_seq_m0_s2 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m0_s2) 
//  function new (string name = "access_seq_m0_s2");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    //write_info (m0,s2,INCR,3,10,3);		////awcache[1]==1
//    read_info(m0,s2,INCR,3,10,3);
//  endtask: body
//endclass : access_seq_m0_s2
//
//
//class access_seq_m0_s3 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m0_s3) 
//  function new (string name = "access_seq_m0_s3");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m0,s3,INCR,3,10,3);		////awcache[1]==1
//    //read_info (m0,s3,INCR,3,10,3);
//  endtask: body
//endclass : access_seq_m0_s3
//
//
///* ************ m1 to all the slave (single master single slave)************* */
//class access_seq_m1_s0 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m1_s0) 
//  function new (string name = "access_seq_m1_s0");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m1,s0,INCR,4,8,0);		//
//    //read_info  (m1,s0,INCR,4,7,0);
//  endtask: body
//endclass : access_seq_m1_s0
//
//
//class access_seq_m1_s1 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m1_s1) 
//  function new (string name = "access_seq_m1_s1");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m1,s1,INCR,4,6,0);		//
//    //read_info  (m1,s1,INCR,8,2,0);
//  endtask: body
//endclass : access_seq_m1_s1
//
//class access_seq_m1_s2 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m1_s2) 
//  function new (string name = "access_seq_m1_s2");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m1,s2,INCR,4,9,0);		//
//    //read_info  (m1,s2,INCR,4,7,0);
//  endtask: body
//endclass : access_seq_m1_s2
//
//class access_seq_m1_s3 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m1_s3) 
//  function new (string name = "access_seq_m1_s3");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m1,s3,INCR,4,7,3);		//upsize--(awcache[1]==1)
//    //read_info (m1,s3,INCR,4,8,3);
//  endtask: body
//endclass : access_seq_m1_s3
//
//
///* ************ m2 to all the slave (single master single slave)************* */
//class access_seq_m2_s0 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m2_s0) 
//  function new (string name = "access_seq_m2_s0");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m2,s0,INCR,5,8,0);
//    //read_info(m2,s0,INCR,5,8,0);
//  endtask: body
//endclass : access_seq_m2_s0
//
//class access_seq_m2_s1 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m2_s1) 
//  function new (string name = "access_seq_m2_s1");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m2,s1,INCR,5,25,0);
//    //read_info(m2,s1,INCR,5,25,0);
//  endtask: body
//endclass : access_seq_m2_s1
//
//class access_seq_m2_s2 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m2_s2) 
//  function new (string name = "access_seq_m2_s2");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m2,s2,INCR,5,7,0); // 7(aligned)
//    //read_info(m2,s2,INCR,5,8,0);
//  endtask: body
//endclass : access_seq_m2_s2
//
//class access_seq_m2_s3 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m2_s3) 
//  function new (string name = "access_seq_m2_s3");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m2,s3,INCR,4,8,0);
//    //read_info(m2,s3,INCR,4,8,0);
//  endtask: body
//endclass : access_seq_m2_s3
//
//
///* ************ m3 to all the slave (single master single slave)************* */
//class access_seq_m3_s0 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m3_s0) 
//  function new (string name = "access_seq_m3_s0");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m3,s0,INCR,2,7,0);
//    //read_info(m3,s0,INCR,2,7,0);
//  endtask: body
//endclass : access_seq_m3_s0
//
//class access_seq_m3_s1 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m3_s1) 
//  function new (string name = "access_seq_m3_s1");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info (m3,s1,INCR,2,25,3);		//awcache[1] =1, 3 transfer,4bytes each
//    //read_info(m3,s1,INCR,2,12,3);
//  endtask: body
//endclass : access_seq_m3_s1
//
//class access_seq_m3_s2 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m3_s2) 
//  function new (string name = "access_seq_m3_s2");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//    write_info(m3,s2,INCR,2,25,3);		//awcache[1]=1	
//    //read_info(m3,s2,INCR,2,12,3);
//  endtask: body
//endclass : access_seq_m3_s2
//
//class access_seq_m3_s3 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m3_s3) 
//  function new (string name = "access_seq_m3_s3");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM)
//      write_info(m3,s3,INCR,2,10,3);		//awcache[1]=1
//      //read_info(m3,s3,INCR,2,10,3);
//  endtask: body
//endclass : access_seq_m3_s3
//
//
///* **************** DOWNSIZE SEQUENCE ***************** */
//class m64_s32_downsize_seq extends base_master_sequence;
//  `uvm_object_utils (m64_s32_downsize_seq) 
//  function new (string name = "m64_s32_downsize_seq");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of m64_s32_downsize_seq body", UVM_MEDIUM) 
//    write_info (m0,s0,INCR,3,250,0);		//14,30,255 -> covg-unalign, align	-----generate again for align
//    //write_info (m0,s0,FIXED,3,7,0);		//12        -> covg-unalign,align-----------------------------change len=12
//    //write_info (m0,s0,WRAP,3,15,0);		//7	    -> covg-align, ERROR-unalign 
//    //read_info  (m0,s0,INCR,3,255,0);		//14,30,255 -> covg-unalign,align
//    //read_info  (m0,s0,FIXED,3,12,0);		//12	    -> covg-unalign,align
//    //read_info  (m0,s0,WRAP,3,7,0);		//7	    -> covg-unalign,align
//  endtask: body
//endclass : m64_s32_downsize_seq
//
//class m128_s32_downsize_seq extends base_master_sequence;
//  `uvm_object_utils (m128_s32_downsize_seq) 
//  function new (string name = "m128_s32_downsize_seq");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of m128_s32_downsize_seq body", UVM_MEDIUM) 
//    //write_info (m1,s0,INCR,4,252,0);		//15,29,252 ->covg-align, unalign
//    //write_info (m1,s0,FIXED,4,11,0);		//11	    ->covg-align,unalign
//    //write_info (m1,s0,WRAP,4,7,0);		//7	    ->covg-align	ERROR in unalign
//    //read_info  (m1,s0,INCR,4,15,0);		//15,29,252 ->covg-align, 29,15->unalign
//    //read_info  (m1,s0,FIXED,4,11,0);		//11-covg-unalign,align
//    read_info  (m1,s0,WRAP,4,7,0);		//7 -covg-unalign, align
//  endtask: body
//endclass : m128_s32_downsize_seq
//
//class m256_s32_downsize_seq extends base_master_sequence;
//  `uvm_object_utils (m256_s32_downsize_seq) 
//  function new (string name = "m256_s32_downsize_seq");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of m256_s32_downsize_seq body", UVM_MEDIUM) 
//    //write_info (m2,s0,INCR,5,150,0);		//10,27,255-covg unlaign
//    //write_info (m2,s0,FIXED,5,12,0);		//12 -covg unalign
//    write_info (m2,s0,WRAP,5,15,0);		//15
//    //read_info  (m2,s0,INCR,5,10,0);		//10,27,253
//    //read_info  (m2,s0,FIXED,5,12,0);		//12
//    //read_info  (m2,s0,WRAP,5,15,0);		//15
//  endtask: body
//endclass : m256_s32_downsize_seq
//
//class m128_s64_downsize_seq extends base_master_sequence;
//  `uvm_object_utils (m128_s64_downsize_seq) 
//  function new (string name = "m128_s64_downsize_seq");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of m128_s64_downsize_seq body", UVM_MEDIUM) 
//    write_info (m1,s1,INCR,4,10,0);		//10,30,255 covg-align,unalign
//    //write_info (m1,s1,FIXED,4,15,0);		//15 covg-align
//    //write_info (m1,s1,WRAP,4,7,0);		//15 covg-align
//    //read_info  (m1,s1,INCR,4,10,0);		//10,30,255 covg-align,unalign 
//    //read_info  (m1,s1,FIXED,4,15,0);		//15 covg-align,unalign
//    //read_info  (m1,s1,WRAP,4,15,0);		//15 covg-align,unalign
//      
//  endtask: body
//endclass : m128_s64_downsize_seq
//
//class m256_s64_downsize_seq extends base_master_sequence;
//  `uvm_object_utils (m256_s64_downsize_seq) 
//  function new (string name = "m256_s64_downsize_seq");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    write_info (m2,s1,INCR,5,250,0);		//15,28,250 covg-unalign
//    //write_info (m2,s1,FIXED,5,14,0);		//14 covg-ualign,align
//    //write_info (m2,s1,WRAP,5,15,0);		//15 covg-align
//    //read_info  (m2,s1,INCR,5,15,0);		//15,28,250 covg-unalign,align
//    //read_info  (m2,s1,FIXED,5,15,0);		//15 covg-unalign,align
//    //read_info  (m2,s1,WRAP,5,15,0);		//15 covg-unalign,align
//  endtask: body
//endclass : m256_s64_downsize_seq
//
//class m256_s128_downsize_seq extends base_master_sequence;
//  `uvm_object_utils (m256_s128_downsize_seq) 
//  function new (string name = "m256_s128_downsize_seq");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of m256_s128_downsize_seq body", UVM_MEDIUM) 
//    //write_info (m2,s2,INCR,5,27,0);		//covg(align,unalign-7)--ERROR in 27, 255
//    //write_info (m2,s2,FIXED,5,15,0);		//covg(align,unalign-15)
//    //write_info (m2,s2,WRAP,5,7,0);		//covg(align-7)
//    //read_info  (m2,s2,INCR,5,10,0);		//covg(align,unalign-10,27)--250 ERROR
//    //read_info  (m2,s2,FIXED,5,15,0);		//covg(align,unalign-15)
//    read_info  (m2,s2,WRAP,5,15,0);		//covg(align,unalign-15)
//  endtask: body
//endclass : m256_s128_downsize_seq
//
//
///* **************** UPSIZE SEQUENCE ***************** */
//class access_seq_m32_s64 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m32_s64) 
//  function new (string name = "access_seq_m32_s64");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    //write_info (m3,s1,INCR,2,11,3);		//11,29,251 ->covg-align,unalign
//    //write_info (m3,s1,FIXED,2,14,3);		//14        ->covg-align,unalign
//    //write_info (m3,s1,WRAP,2,15,3);		//15	    ->covg-align,unalign
//    //read_info  (m3,s1,INCR,2,252,3);		//11,29,252 ->covg-align,unalign
//    //read_info  (m3,s1,FIXED,2,14,3);		//14	    ->covg-align,unalign
//    read_info  (m3,s1,WRAP,2,15,3);		//15	    ->covg-align, unalign 
//  endtask: body
//endclass : access_seq_m32_s64
//
//class access_seq_m32_s128 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m32_s128) 
//  function new (string name = "access_seq_m32_s128");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    //write_info (m3,s2,INCR,2,10,3);		//10,28->covg-unalign--251 is not working,align
//    //write_info (m3,s2,FIXED,2,11,3);		//11->covg-unalign,align
//    write_info (m3,s2,WRAP,2,7,3);		//7->covg-unalign,align
//    //read_info  (m3,s2,INCR,2,10,3);		//10,28,251 ->covg unalign,align
//    //read_info  (m3,s2,FIXED,2,11,3);		//11->covg unalign,align
//    //read_info  (m3,s2,WRAP,2,7,3);		//7 -> covg ->unalign, align
//  endtask: body
//endclass : access_seq_m32_s128
//
//class access_seq_m32_s256 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m32_s256) 
//  function new (string name = "access_seq_m32_s256");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    write_info (m3,s3,INCR,2,25,3);		//9,25,250- align-covg,unalign
//    //write_info (m3,s3,FIXED,2,13,3);		//13- covg->align,unalign
//    //write_info (m3,s3,WRAP,2,15,3);		//15 covg->align,unalign
//    //read_info  (m3,s3,INCR,2,9,3);		//9,25,250->covg align,unalign
//    //read_info  (m3,s3,FIXED,2,13,3);		//13	->covg align,unalign
//    //read_info  (m3,s3,WRAP,2,15,3);		//15	->covg align,unalign
//  endtask: body
//endclass : access_seq_m32_s256
//
//class access_seq_m64_s128 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m64_s128) 
//  function new (string name = "access_seq_m64_s128");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    //write_info (m0,s2,INCR,3,254,3);		//8,27, -covg->unalign,align (255 fatal error,not comming out from IC)
//    //write_info (m0,s2,FIXED,3,12,3);		//12   -covg-> unalign,align
//    //write_info (m0,s2,WRAP,3,7,3);		//7    -covg->unalign,align
//    read_info  (m0,s2,INCR,3,254,3);		//8,27,254 -covg->unalign,align
//    //read_info  (m0,s2,FIXED,3,12,3);		//12    -covg->unalign,align
//    //read_info  (m0,s2,WRAP,3,7,3);		//7     -covg->unalign,align
//  endtask: body
//endclass : access_seq_m64_s128
//
//
//class access_seq_m64_s256 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m64_s256) 
//  function new (string name = "access_seq_m64_s256");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    //write_info (m0,s3,INCR,3,7,3);		//covg(7,26,253-align&unalign)
//    //write_info (m0,s3,FIXED,3,15,3);		//covg(15-align&unalign)
//    //write_info (m0,s3,WRAP,3,7,3);		//covg(7-align&unalign) 
//    //read_info  (m0,s3,INCR,3,253,3);		//covg(7,26,253-align&unalign)
//    //read_info  (m0,s3,WRAP,3,7,3);		//covg(7-align)
//    read_info  (m0,s3,FIXED,3,15,3);		//covg(15-align)
//  endtask: body
//endclass : access_seq_m64_s256
//
//class access_seq_m128_s256 extends base_master_sequence;
//  `uvm_object_utils (access_seq_m128_s256) 
//  function new (string name = "access_seq_m128_s256");
//    super.new (name); 
//  endfunction
//
//  task body ();
//    `uvm_info (get_full_name(), "inside of access_test_seq body", UVM_MEDIUM) 
//    //write_info (m1,s3,INCR,4,254,3);		//10,29,254 (covg-align&unalign)
//    //write_info (m1,s3,FIXED,4,11,3);		//11(covg-align&unalign)
//   // write_info (m1,s3,WRAP,4,15,3);		//15(covg-align&unalign)
//    read_info  (m1,s3,INCR,4,10,3);		//10,29,255(covg-align&unalign)
//    //read_info  (m1,s3,FIXED,4,11,3);		//11(covg-unalign&align)
//    //read_info  (m1,s3,WRAP,4,15,3);		//15(covg-unalign&align)
//  endtask: body
//endclass : access_seq_m128_s256
//
//
//
///* **************** DECODE_ERROR_SEQUENCE ***************** */
//class decode_error_seq extends base_master_sequence;
//
//   `uvm_object_utils(decode_error_seq)
//
//   function new (string name = "decode_error_seq");
//      super.new (name);
//   endfunction : new
//
//   task body();
//      master_seq_item  pkt = master_seq_item :: type_id :: create ("pkt");
//      `uvm_info(get_full_name(), "inside decode error sequence body", UVM_MEDIUM)
//      start_item (pkt);
//      assert (pkt.randomize() with {operation == /*WRITE;//*/READ;
//                		    //awid==i;
//			            //awaddr inside {[32'h44a4_0000 : 32'h44af_ffff]};
//				    //awburst== INCR;
//				    //awlen inside{[0:15]};
//                                    //awsize == 3;
//                                    //pkt.awcache== 0;pkt.awlock== 0; pkt.awqos== 0; pkt.awprot== 0;pkt.awregion==0;
//                                    //pkt.resp_ready_dly== 0;pkt.cmd2cmd_dly== 0;pkt.add2data_dly== 0;
//	                            araddr inside {[32'h44a4_0000 : 32'h44af_ffff]};
//				    //arid==i;
//				    arburst== INCR;
//				    arlen ==5;
//				    arsize == 3;
//                                    pkt.arcache== 0;pkt.arlock== 0; pkt.arqos== 0; pkt.arprot== 0;pkt.arregion==0;
//                                    pkt.resp_ready_dly== 0;pkt.cmd2cmd_dly== 0;pkt.add2data_dly== 0;
//				    })
//        else `uvm_error (get_full_name(),"randomization failed");
//        finish_item (pkt);
//        `uvm_info(get_full_name(), "inside decode error sequence body", UVM_MEDIUM)
//      //end
//  endtask : body
//endclass : decode_error_seq
//
//
///************************* split transaction seq *************************/
//class split_trans_seq extends base_master_sequence;
//  `uvm_object_utils (split_trans_seq)
//  
//  function new (string name="split_trans_seq");
//    super.new(name);
//  endfunction:new
//
//  task body();
//    master_seq_item pkt = master_seq_item :: type_id :: create("pkt");
//    //for(int i=0;i<4;i++)begin
//    //repeat(4) begin
//      start_item(pkt);
//      assert(pkt.randomize() with {operation == WRITE;//READ;
//				   awaddr    == 32'h44A0_0000;
//				   //awid      == i;
//                                   awlen   == 100;//inside {[30:255]};	//not support(m0_s0)-255,170,145,143,142
//                                   awsize    == 5;
//                                   awburst   == INCR;
//                                   pkt.awcache== 0;pkt.awlock== 0; pkt.awqos== 0; pkt.awprot== 0;pkt.awregion==0;
//                                   pkt.resp_ready_dly== 0;pkt.cmd2cmd_dly== 0;pkt.add2data_dly== 0;
//                                   })
//      else `uvm_error(get_full_name(),"randomization FAILED")
//     finish_item(pkt);
//     `uvm_info(get_full_name(), "inside split_trans_seq body", UVM_MEDIUM)   
//    
//  endtask:body
//endclass:split_trans_seq
//
///******************** Back Pressure Test Sequence ********************
//class ic_fifo_back_pressure_seq extends base_master_sequence;
//  `uvm_object_utils (ic_fifo_back_pressure_seq)
//
//  function new (string name="ic_fifo_back_pressure_seq");
//    super.new(name);
//  endfunction:new
//
//  task body();
//    master_seq_item pkt = master_seq_item::type_id:: create("pkt");
//    `uvm_info(get_full_name(), "inside ic_fifo_back_pressure sequence body", UVM_MEDIUM)   
//    for(int i=0;i<100;i++)begin						//100 transaction
//      start_item(pkt);
//      assert(pkt.randomize() with {operation == WRITE;
//				   awaddr    == 32'h44a2_0000;		//tergetting slave-0(4bytes)
//				   awid      == i;
//				   awlen     == 11;			//12 transfer==> 
//                                   awsize    == 3;			//8bytes(master 0)
//                                   awburst   == INCR;
//                                   pkt.awcache == 0;
//				   pkt.awlock  == 0;
//				   pkt.awqos   == 0;
//				   pkt.awprot  == 0;
//				   pkt.awregion==0;
//				//delay is zerro for back to back transactions
//                                   pkt.resp_ready_dly    == 0;
//				   pkt.cmd2cmd_dly       == 0;
//				   pkt.add2data_dly      == 0;
//                                   add_valid_dly         == 0;
//				   write_valid2valid_dly ==0;
//				   });
//    else `uvm_fatal(get_full_name(),"randomization FAILED")
//    finish_item(pkt);
//   end
//  endtask:body
//
//  
//endclass: ic_fifo_back_pressure_seq
//
//*/
//
//class random_test_seq extends base_master_sequence;
//  `uvm_object_utils (random_test_seq)
//
//  function new (string name="random_test_seq");
//    super.new(name);
//  endfunction:new
//
//  task body();
//    master_seq_item pkt = master_seq_item::type_id:: create("pkt");
//    `uvm_info(get_full_name(), "inside random_test_seq sequence body", UVM_MEDIUM)   
//      start_item(pkt);
//      assert(pkt.randomize())
//      else `uvm_fatal(get_full_name(),"randomization FAILED")
//      finish_item(pkt);
//      get_response(pkt);
//  endtask:body
//endclass: random_test_seq
//
///////////////////////////////////////////////////////////////////
//class out_of_range_addr_downsize_seq extends base_master_sequence;
//  `uvm_object_utils (out_of_range_addr_downsize_seq)
//
//  function new (string name="out_of_range_addr_downsize_seq");
//    super.new(name);
//  endfunction:new
//
//  task body();
//    master_seq_item pkt = master_seq_item::type_id:: create("pkt");
//    `uvm_info(get_full_name(), "inside random_test_seq sequence body", UVM_MEDIUM)   
//      start_item(pkt);
//      assert(pkt.randomize() with {operation == WRITE;//READ;
//				   awaddr == 32'h44A0FFE0;
//                                   awlen   == 15;
//                                   awsize    == 5;
//                                   awburst   == INCR;//WRAP;
//                                   pkt.awcache== 0;pkt.awlock== 0; pkt.awqos== 0; pkt.awprot== 0;pkt.awregion==0;
//                                   pkt.resp_ready_dly== 0;pkt.cmd2cmd_dly== 0;pkt.add2data_dly== 0;
//                                   })
//      else `uvm_fatal(get_full_name(),"randomization FAILED")
//      finish_item(pkt);
//      get_response(pkt);
//  endtask:body
//endclass: out_of_range_addr_downsize_seq





