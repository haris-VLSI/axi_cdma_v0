class cdma_base_test extends uvm_test;
    `uvm_component_utils(cdma_base_test)

    function new(string name = "cdma_base_test", uvm_component parent);
        super.new(name,parent);
    endfunction
    
    cdma_env        env;
    config_obj      obj;					//config_object

    //cdma_base_test:: build
    function void build_phase 			(uvm_phase phase);
        super.build_phase (phase);
        `uvm_info ("test::build_phase" , phase.get_name() , UVM_MEDIUM)
        env = cdma_env :: type_id :: create ("env", this);	//creating axi_cdma_env 
        if(!uvm_config_db #(config_obj) :: get(this, "", "config_obj", obj))
            `uvm_fatal (get_full_name(), "config_db_not_accessable");
    endfunction : build_phase

  //cdma_base_test:: elaboration
  function void end_of_elaboration_phase 	(uvm_phase phase);
     super.end_of_elaboration_phase (phase);
    `uvm_info ("test::end_of_elaboration"  , phase.get_name() , UVM_MEDIUM)
    uvm_top.print_topology();								//printing topology
    env.reg_block.default_map.print();
    env.reg_block.print();
     
  endfunction : end_of_elaboration_phase

  //cdma_base_test:: reset_phase
    task reset_phase(uvm_phase phase);
        super.reset_phase(phase);
        `uvm_info(get_full_name(),"inside_reset_phase", UVM_MEDIUM)
        phase.raise_objection(this);
        `uvm_info(get_full_name(),"inside_raise_objection", UVM_MEDIUM)
        wait (obj.mas_if[0].areset_n);
        //#1000;
        phase.drop_objection(this);
        `uvm_info(get_full_name(),"outside_drop_objection", UVM_MEDIUM)
    endtask: reset_phase
 endclass :cdma_base_test

class reg_access_test extends cdma_base_test;
  `uvm_component_utils (reg_access_test) 
  reg_access_seq reg_seq;
   
  function new (string name = "reg_access_test", uvm_component parent);
    super.new (name, parent);
  endfunction

    task main_phase(uvm_phase phase);
        phase.raise_objection(this);
            reg_seq = reg_access_seq::type_id::create("reg_seq");
            reg_seq.start(env.m_agt[0].sqr);
            #2000;
        phase.drop_objection(this);
    endtask
endclass: reg_access_test

class reg_write_test extends cdma_base_test;
    `uvm_component_utils (reg_write_test) 
    //reg_write_read_seq reg_seq;
    reg_write_read_vseq w_r_vseq;

    //function new (string name = "reg_write_test", uvm_component parent);
    function new (string name = "reg_write_read_vseq", uvm_component parent);
        super.new (name, parent);
    endfunction

    task main_phase(uvm_phase phase);
        phase.raise_objection(this);
            //reg_seq = reg_write_read_seq::type_id::create("reg_seq");
            w_r_vseq = reg_write_read_vseq::type_id::create("w_r_vseq");
            w_r_vseq.start(env.v_seqr);
            #3000;
        phase.drop_objection(this);
    endtask
endclass: reg_write_test


class ral_reset_test_t extends cdma_base_test;
//reading from cdmacr only
  `uvm_component_utils(ral_reset_test_t)

  function new(string name="ral_reset_test_t", uvm_component parent);
    super.new(name,parent);
  endfunction
  
  ral_read_all_seq seq;

  task main_phase(uvm_phase phase);
    `uvm_info(get_full_name(), "ral_reset_test_t: main_phase start", UVM_LOW)
    phase.raise_objection(this);
    seq = ral_read_all_seq::type_id::create("ral_read_all_seq");
    seq.model = env.reg_block;
    seq.start(null);
    #100;
    `uvm_info(get_full_name(), "ral_reset_test_t: sequence finished", UVM_LOW)
    phase.drop_objection(this);
  endtask : main_phase

endclass : ral_reset_test_t


class ral_write_all_test extends cdma_base_test;
  `uvm_component_utils(ral_write_all_test)

  function new(string name="ral_write_all_test", uvm_component parent);
    super.new(name,parent);
  endfunction

  ral_write_all_seq write_seq;
  
  task main_phase(uvm_phase phase);
    phase.raise_objection(this);
        write_seq = ral_write_all_seq::type_id::create("write_seq");
        write_seq.model = env.reg_block;
        write_seq.start(null);
        #3000;
    phase.drop_objection(this);
    endtask
endclass


//class simple_mode_incr_transfer_test extends cdma_base_test;
//  `uvm_component_utils(simple_mode_incr_transfer_test)
//
//  function new(string name="simple_mode_incr_transfer_test", uvm_component parent=null);
//    super.new(name,parent);
//  endfunction
//
//  cdma_config_seq cfg_seq;
//  cdma_data_seq cap_seq;
//  //cdma_capture_seq cap_seq;
//
//  task main_phase(uvm_phase phase);
//    phase.raise_objection(this);
//        cfg_seq = cdma_config_seq::type_id::create("cfg_seq");
//        cfg_seq.start(env.m_agt[0].sqr);
//        #1000;
//        //cap_seq = cdma_capture_seq::type_id::create("cap_seq");
//        cap_seq = cdma_data_seq::type_id::create("cap_seq");
//        cap_seq.start(env.s_agt[0].sqr);
//        #10000;
//    phase.drop_objection(this);
//  endtask
//endclass : simple_mode_incr_transfer_test


class ral_reset_test extends cdma_base_test;
    `uvm_component_utils(ral_reset_test)

    function new(string name="ral_reset_test", uvm_component parent);
        super.new(name,parent);
    endfunction
    
    uvm_status_e status;
    uvm_reg_data_t value = 32'hffff_ffff;

    uvm_reg_hw_reset_seq reset_seq;

    task main_phase(uvm_phase phase);
        phase.raise_objection(this);
            reset_seq = uvm_reg_hw_reset_seq::type_id::create("reset_seq");
            reset_seq.model = env.reg_block;

            //writing random values before reset test
            env.reg_block.cdmacr.write(status,32'h0);
            env.reg_block.cdmasr.write(status,value);
            env.reg_block.curdesc_pnt.write(status,value);
            env.reg_block.curdesc_pnt_msb.write(status,value);
            env.reg_block.taildesc_pnt.write(status,value);
            env.reg_block.taildesc_pnt_msb.write(status,value);
            env.reg_block.sa.write(status,value);
            env.reg_block.sa_msb.write(status,value);
            env.reg_block.da.write(status,value);
            env.reg_block.da_msb.write(status,value);
            //env.reg_block.btt.write(status,value);

            `uvm_info("RAL_RESET_TEST","Soft reset asserted",UVM_MEDIUM)
            env.reg_block.cdmacr.Reset.write(status,1'b1);
            do begin
                env.reg_block.cdmacr.Reset.read(status,value);
            end while(value == 1);
            `uvm_info("RAL_RESET_TEST","Soft reset cleared",UVM_MEDIUM)

            //clears RAL mirror values
            env.reg_block.reset();
            `uvm_info("RAL_RESET_TEST","RAL reset completed",UVM_MEDIUM)

            `uvm_info("RAL_RESET_TEST","RAL reset test starting",UVM_MEDIUM)
            reset_seq.start(null);
            `uvm_info("RAL_RESET_TEST","RAL reset test completed",UVM_MEDIUM)
        phase.drop_objection(this);
    endtask
endclass: ral_reset_test


class ral_bit_bash_test extends cdma_base_test;
  `uvm_component_utils(ral_bit_bash_test)
    
    uvm_status_e    status;
    uvm_reg_data_t  value = 32'h0000_0008;
    uvm_reg_data_t  rdata;

  function new(string name="ral_bit_bash_test", uvm_component parent);
    super.new(name,parent);
  endfunction

  uvm_reg_bit_bash_seq bit_bash_seq;
  
  task main_phase(uvm_phase phase);
    phase.raise_objection(this);
        bit_bash_seq = uvm_reg_bit_bash_seq::type_id::create("bit_bash_seq");
        bit_bash_seq.model = env.reg_block;

        env.reg_block.cdmacr.write(status,value);
        env.reg_block.cdmacr.read(status,value);
        `uvm_info("DEBUG", $sformatf("Read CR: 0x%0h", value), UVM_LOW)
        #10;
        env.reg_block.cdmacr.SGMode.read(status,value);
        `uvm_info("DEBUG", $sformatf("Read CR SGMode: 0x%0h", value), UVM_LOW)
        #10;
        env.reg_block.cdmasr.read(status,value);
        `uvm_info("DEBUG", $sformatf("Read SR: 0x%0h", value), UVM_LOW)
        #10;
        env.reg_block.cdmasr.Idle.read(status,value);
        `uvm_info("DEBUG", $sformatf("Read SR Idle: 0x%0h", value), UVM_LOW)
        #10;
        //env.reg_block.curdesc_pnt.write(status,32'hFFFFFFFF);
        //env.reg_block.curdesc_pnt.read(status,rdata);
        //`uvm_info("DEBUG", $sformatf("Read: 0x%0h", rdata), UVM_LOW)
        //#10;
        
        uvm_resource_db#(bit)::set({"REG::",env.reg_block.cdmacr.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::", env.reg_block.cdmacr.reset.get_full_name()}, "NO_REG_BIT_BASH_TEST", 1);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.cdmasr.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.curdesc_pnt.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.curdesc_pnt_msb.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.taildesc_pnt.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.taildesc_pnt_msb.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.sa.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.sa_msb.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.da.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.da_msb.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.btt.get_full_name()},"NO_REG_TESTS",1,this);

        fork
            bit_bash_seq.start(null);
            begin
                #1;
                bit_bash_seq.reg_seq.set_response_queue_error_report_disabled(1);
            end
        join

    phase.drop_objection(this);
    endtask
endclass : ral_bit_bash_test


class ral_access_test extends cdma_base_test;
    `uvm_component_utils(ral_access_test)
    uvm_status_e    status;
    uvm_reg_data_t  value;

    function new(string name="reg_access_seq", uvm_component parent);
        super.new(name,parent);
    endfunction

    uvm_reg_access_seq reg_access_seq;

    task main_phase(uvm_phase phase);
        phase.raise_objection(this);
        reg_access_seq = uvm_reg_access_seq::type_id::create("reg_access_seq");
        reg_access_seq.model = env.reg_block;

        env.reg_block.cdmacr.write(status, 32'h8);
        env.reg_block.cdmacr.read(status,value);
        `uvm_info("DEBUG", $sformatf("Read CR SGMode: 0x%0h", value[3]), UVM_LOW)
        #10;

        uvm_resource_db#(bit)::set({"REG::",env.reg_block.cdmacr.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.cdmasr.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.curdesc_pnt.get_full_name()},"NO_REG_TESTS",1,this);
        uvm_resource_db#(bit)::set({"REG::",env.reg_block.taildesc_pnt.get_full_name()},"NO_REG_TESTS",1,this);
        //uvm_resource_db#(bit)::set({"REG::",env.reg_block.taildesc_pnt_msb.get_full_name()},"NO_REG_TESTS",1,this);
        
        env.reg_block.cdmasr.read(status,value);
        `uvm_info("DEBUG", $sformatf("Read SR for Idle: 0x%0h", value[1]), UVM_LOW)

        do begin
            @(posedge obj.mas_if[0].aclk);
        end while(value[1]==0);

        `uvm_info("DEBUG", $sformatf("Read SR after wait for Idle: 0x%0h", value[1]), UVM_LOW)

        reg_access_seq.start(null);
        phase.drop_objection(this);
    endtask
endclass: ral_access_test


class simple_mode_wr_rd_test extends cdma_base_test;
    `uvm_component_utils(simple_mode_wr_rd_test)
    
    cdma_simple_transfer_vseq vseq;

    function new(string name="simple_mode_wr_rd_test", uvm_component parent);
        super.new(name,parent);
    endfunction

    task main_phase(uvm_phase phase);
        vseq = cdma_simple_transfer_vseq::type_id::create("vseq");
        
        phase.raise_objection(this);
            env.v_seqr.reg_block    =   env.reg_block;
            vseq.start(env.v_seqr);
        phase.drop_objection(this);
    endtask
endclass: simple_mode_wr_rd_test


class simple_mode_incr_transfer_test extends cdma_base_test;
    `uvm_component_utils(simple_mode_incr_transfer_test)
    
    function new(string name="simple_mode_incr_transfer_test", uvm_component parent);
        super.new(name,parent);
    endfunction

    simple_mode_wr_rd_seq   master_seq;
    base_slave_sequence     slave_seq;
    
    task main_phase(uvm_phase phase);
        phase.raise_objection(this);
            master_seq = simple_mode_wr_rd_seq::type_id::create("master_seq");
            slave_seq  = base_slave_sequence::type_id::create("slave_seq");
            fork
                slave_seq.start(env.s_agt[0].sqr);
            join_none
            master_seq.start(env.m_agt[0].sqr);
        phase.drop_objection(this);
    endtask
endclass: simple_mode_incr_transfer_test


class simple_mode_fixed_transfer_test extends cdma_base_test;
    `uvm_component_utils(simple_mode_fixed_transfer_test)

    function new(string name="simple_mode_fixed_transfer_test", uvm_component parent);
        super.new(name,parent);
    endfunction
    
    simple_mode_fixed_seq   fixed_seq;
    base_slave_sequence     slave_seq;

    task main_phase(uvm_phase phase);
        phase.raise_objection(this);
        fixed_seq = simple_mode_fixed_seq::type_id::create("fixed_seq");
        slave_seq = base_slave_sequence::type_id::create("slave_seq");
        fork
            slave_seq.start(env.s_agt[0].sqr);
        join_none
            fixed_seq.start(env.m_agt[0].sqr);
        phase.drop_objection(this);
    endtask

endclass: simple_mode_fixed_transfer_test








































//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    
//    phase.raise_objection(this);
//        reg_seq = reg_access_seq::type_id::create("reg_seq");
//        `uvm_info (get_full_name(), "inside_raise_objection main_phase", UVM_MEDIUM)
//        reg_seq.start(env.m_agt[0].sqr);
//        //phase.phase_done.set_drain_time(this,15000);
//        `uvm_info (get_full_name(), "after_running_seq main_phase", UVM_MEDIUM)
//        //@(posedge obj.mas_if[0].arready);
//        //@(posedge obj.mas_if[0].rvalid);
//        //@(negedge obj.mas_if[0].arvalid);
//        //@(negedge obj.mas_if[0].rready);
//        #1000;
//        `uvm_info (get_full_name(), "before_drop_objection", UVM_MEDIUM)
//    phase.drop_objection(this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//
//    //`uvm_info (get_full_name(), $sformat("phase_objections: %d",phase.print_objections()), UVM_MEDIUM)
//  endtask


    //reg_seq.set_starting_phase(phase);
    //reg_seq.set_automatic_phase_objection(1);
    //phase.get_objection().display_objections(this);
    //phase.print_objections();
    //phase.get_objection().display_objections(this);
    //phase.get_objection().print_objection_summary(this);























































///* *************** access_test ***************** */
//class m0_s0_access_test extends ic_base_test;
//  `uvm_component_utils (m0_s0_access_test) 
//  m0_s0_access_test_vseq m0_s0_vseq;
//
//  function new (string name = "m0_s0_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m0_s0_vseq = m0_s0_access_test_vseq :: type_id :: create ("m0_s0_vseq");
//    phase.raise_objection (this);
////    m0_s0_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m0_s0_access_test
//
//class m0_s1_access_test extends ic_base_test;
//  `uvm_component_utils (m0_s1_access_test) 
//  m0_s1_access_test_vseq m0_s1_vseq;
//   
//  function new (string name = "m0_s1_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m0_s1_vseq = m0_s1_access_test_vseq :: type_id :: create ("m0_s1_vseq");
//    phase.raise_objection (this);
////    m0_s1_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m0_s1_access_test
//
//class m0_s2_access_test extends ic_base_test;
//  `uvm_component_utils (m0_s2_access_test) 
//  m0_s2_access_test_vseq m0_s2_vseq;
//   
//  function new (string name = "m0_s2_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m0_s2_vseq = m0_s2_access_test_vseq :: type_id :: create ("m0_s2_vseq");
//    phase.raise_objection (this);
////    m0_s2_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m0_s2_access_test
//
//class m0_s3_access_test extends ic_base_test;
//  `uvm_component_utils (m0_s3_access_test) 
//  m0_s3_access_test_vseq m0_s3_vseq;
//   
//  function new (string name = "m0_s3_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m0_s3_vseq = m0_s3_access_test_vseq :: type_id :: create ("m0_s3_vseq");
//    phase.raise_objection (this);
////    m0_s3_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m0_s3_access_test
//
///* ************ m1 to all single slave ************ */
//class m1_s0_access_test extends ic_base_test;
//  `uvm_component_utils (m1_s0_access_test) 
//  m1_s0_access_test_vseq m1_s0_vseq;
//   
//  function new (string name = "m1_s0_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m1_s0_vseq = m1_s0_access_test_vseq :: type_id :: create ("m1_s0_vseq");
//    phase.raise_objection (this);
////    m1_s0_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m1_s0_access_test
//
//
//class m1_s1_access_test extends ic_base_test;
//  `uvm_component_utils (m1_s1_access_test) 
//  m1_s1_access_test_vseq m1_s1_vseq;
//   
//  function new (string name = "m1_s1_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m1_s1_vseq = m1_s1_access_test_vseq :: type_id :: create ("m1_s1_vseq");
//    phase.raise_objection (this);
////    m1_s1_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m1_s1_access_test
//
//class m1_s2_access_test extends ic_base_test;
//  `uvm_component_utils (m1_s2_access_test) 
//  m1_s2_access_test_vseq m1_s2_vseq;
//   
//  function new (string name = "m1_s2_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m1_s2_vseq = m1_s2_access_test_vseq :: type_id :: create ("m1_s2_vseq");
//    phase.raise_objection (this);
////    m1_s2_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m1_s2_access_test
//
//class m1_s3_access_test extends ic_base_test;
//  `uvm_component_utils (m1_s3_access_test) 
//  m1_s3_access_test_vseq m1_s3_vseq;
//   
//  function new (string name = "m1_s3_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m1_s3_vseq = m1_s3_access_test_vseq :: type_id :: create ("m1_s3_vseq");
//    phase.raise_objection (this);
////    m1_s3_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m1_s3_access_test
//
///* ********** m2 to all all single slave ************ */
//class m2_s0_access_test extends ic_base_test;
//  `uvm_component_utils (m2_s0_access_test) 
//  m2_s0_access_test_vseq m2_s0_vseq;
//   
//  function new (string name = "m2_s0_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m2_s0_vseq = m2_s0_access_test_vseq :: type_id :: create ("m2_s0_vseq");
//    phase.raise_objection (this);
////    m2_s0_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m2_s0_access_test
//
//
//class m2_s1_access_test extends ic_base_test;
//  `uvm_component_utils (m2_s1_access_test) 
//  m2_s1_access_test_vseq m2_s1_vseq;
//   
//  function new (string name = "m2_s1_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m2_s1_vseq = m2_s1_access_test_vseq :: type_id :: create ("m2_s1_vseq");
//    phase.raise_objection (this);
////    m2_s1_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m2_s1_access_test
//
//class m2_s2_access_test extends ic_base_test;
//  `uvm_component_utils (m2_s2_access_test) 
//  m2_s2_access_test_vseq m2_s2_vseq;
//   
//  function new (string name = "m2_s2_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m2_s2_vseq = m2_s2_access_test_vseq :: type_id :: create ("m2_s2_vseq");
//    phase.raise_objection (this);
////    m2_s2_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m2_s2_access_test
//
//class m2_s3_access_test extends ic_base_test;
//  `uvm_component_utils (m2_s3_access_test) 
//  m2_s3_access_test_vseq m2_s3_vseq;
//   
//  function new (string name = "m2_s3_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m2_s3_vseq = m2_s3_access_test_vseq :: type_id :: create ("m2_s3_vseq");
//    phase.raise_objection (this);
////    m2_s3_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m2_s3_access_test
//
//
///* ********** m3 to all all single slave ************ */
//class m3_s0_access_test extends ic_base_test;
//  `uvm_component_utils (m3_s0_access_test) 
//  m3_s0_access_test_vseq m3_s0_vseq;
//   
//  function new (string name = "m3_s0_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m3_s0_vseq = m3_s0_access_test_vseq :: type_id :: create ("m3_s0_vseq");
//    phase.raise_objection (this);
////    m3_s0_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m3_s0_access_test
//
//
//class m3_s1_access_test extends ic_base_test;
//  `uvm_component_utils (m3_s1_access_test) 
//  m3_s1_access_test_vseq m3_s1_vseq;
//   
//  function new (string name = "m3_s1_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m3_s1_vseq = m3_s1_access_test_vseq :: type_id :: create ("m3_s1_vseq");
//    phase.raise_objection (this);
////    m3_s1_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m3_s1_access_test
//
//class m3_s2_access_test extends ic_base_test;
//  `uvm_component_utils (m3_s2_access_test) 
//  m3_s2_access_test_vseq m3_s2_vseq;
//   
//  function new (string name = "m3_s2_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m3_s2_vseq = m3_s2_access_test_vseq :: type_id :: create ("m3_s2_vseq");
//    phase.raise_objection (this);
////    m3_s2_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m3_s2_access_test
//
//class m3_s3_access_test extends ic_base_test;
//  `uvm_component_utils (m3_s3_access_test) 
//  m3_s3_access_test_vseq m3_s3_vseq;
//   
//  function new (string name = "m3_s3_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside access test main_phase", UVM_MEDIUM)
//    m3_s3_vseq = m3_s3_access_test_vseq :: type_id :: create ("m3_s3_vseq");
//    phase.raise_objection (this);
//    m3_s3_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "access_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m3_s3_access_test
//
///* *********** Multi Master Multi Slave access test ********** */
//class multi_master_multi_slave_access_test extends ic_base_test;
//  `uvm_component_utils (multi_master_multi_slave_access_test) 
//  multi_master_multi_slave_access_vseq m_s_vseq;
//   
//  function new (string name = "multi_master_multi_slave_access_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside multi_master_multi_slave_test main_phase", UVM_MEDIUM)
//    m_s_vseq = multi_master_multi_slave_access_vseq :: type_id :: create ("m_s_vseq");
//    phase.raise_objection (this);
//    m_s_vseq.start (vseqr);
//    repeat (2000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "multi_master_multi_slave_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: multi_master_multi_slave_access_test
//
//
///* ************** Width Conversion Test ************** */
///**************** DOWNSIZE ****************************/
//class m64_s32_downsize_test extends ic_base_test;
//  `uvm_component_utils (m64_s32_downsize_test) 
//  m64_s32_width_conv_vseq m64_s32_vseq;
//   
//  function new (string name = "m64_s32_downsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m64_s32_downsize_test main_phase", UVM_MEDIUM)
//    m64_s32_vseq = m64_s32_width_conv_vseq :: type_id :: create ("m64_s32_vseq");
//    phase.raise_objection (this);
//    m64_s32_vseq.start (vseqr);
//    repeat (35000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m64_s32_downsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m64_s32_downsize_test
//
//class m128_s32_downsize_test extends ic_base_test;
//  `uvm_component_utils (m128_s32_downsize_test) 
//  m128_s32_width_conv_vseq m128_s32_vseq;
//   
//  function new (string name = "m128_s32_downsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m128_s32_downsize_test main_phase", UVM_MEDIUM)
//    m128_s32_vseq = m128_s32_width_conv_vseq :: type_id :: create ("m128_s32_vseq");
//    phase.raise_objection (this);
//    m128_s32_vseq.start (vseqr);
//    repeat (23000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m128_s32_downsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m128_s32_downsize_test
//
//class m256_s32_downsize_test extends ic_base_test;
//  `uvm_component_utils (m256_s32_downsize_test) 
//  m256_s32_width_conv_vseq m256_s32_vseq;
//   
//  function new (string name = "m256_s32_downsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m256_s32_downsize_test main_phase", UVM_MEDIUM)
//    m256_s32_vseq = m256_s32_width_conv_vseq :: type_id :: create ("m256_s32_vseq");
//    phase.raise_objection (this);
//    m256_s32_vseq.start (vseqr);
//    repeat (55000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m256_s32_downsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m256_s32_downsize_test
//
//class m128_s64_downsize_test extends ic_base_test;
//  `uvm_component_utils (m128_s64_downsize_test) 
//  m128_s64_width_conv_vseq m128_s64_vseq;
//   
//  function new (string name = "m128_s64_downsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m128_s64_downsize_test main_phase", UVM_MEDIUM)
//    m128_s64_vseq = m128_s64_width_conv_vseq :: type_id :: create ("m128_s64_vseq");
//    phase.raise_objection (this);
//    m128_s64_vseq.start (vseqr);
//    repeat (50000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m128_s64_downsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m128_s64_downsize_test
//
//class m256_s64_downsize_test extends ic_base_test;
//  `uvm_component_utils (m256_s64_downsize_test) 
//  m256_s64_width_conv_vseq m256_s64_vseq;
//   
//  function new (string name = "m256_s64_downsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m256_s64_downsize_test main_phase", UVM_MEDIUM)
//    m256_s64_vseq = m256_s64_width_conv_vseq :: type_id :: create ("m256_s64_vseq");
//    phase.raise_objection (this);
//    m256_s64_vseq.start (vseqr);
//    repeat (60000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m256_s64_downsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m256_s64_downsize_test
//
//class m256_s128_downsize_test extends ic_base_test;
//  `uvm_component_utils (m256_s128_downsize_test) 
//  m256_s128_width_conv_vseq m256_s128_vseq;
//   
//  function new (string name = "m256_s128_downsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m256_s128_downsize_test main_phase", UVM_MEDIUM)
//    m256_s128_vseq = m256_s128_width_conv_vseq :: type_id :: create ("m256_s128_vseq");
//    phase.raise_objection (this);
//    m256_s128_vseq.start (vseqr);
//    repeat (35000) @ (posedge obj.mas_if[0].aclk);		//increased time=50000, fatal error
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m256_s128_downsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m256_s128_downsize_test
//
///**************************** UPSIZE ******************************** */
//class m32_s64_upsize_test extends ic_base_test;
//  `uvm_component_utils (m32_s64_upsize_test) 
//  m32_s64_width_conv_vseq m32_s64_vseq;
//   
//  function new (string name = "m32_s64_upsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m32_s64_upsize_test main_phase", UVM_MEDIUM)
//    m32_s64_vseq = m32_s64_width_conv_vseq :: type_id :: create ("m32_s64_vseq");
//    phase.raise_objection (this);
//    m32_s64_vseq.start (vseqr);
//    repeat (9000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m32_s64_upsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m32_s64_upsize_test
//
//class m32_s128_upsize_test extends ic_base_test;
//  `uvm_component_utils (m32_s128_upsize_test) 
//  m32_s128_width_conv_vseq m32_s128_vseq;
//   
//  function new (string name = "m32_s128_upsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m32_s128_upsize_test main_phase", UVM_MEDIUM)
//    m32_s128_vseq = m32_s128_width_conv_vseq :: type_id :: create ("m32_s128_vseq");
//    phase.raise_objection (this);
//    m32_s128_vseq.start (vseqr);
//    repeat (9000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m32_s128_upsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m32_s128_upsize_test
//
//class m32_s256_upsize_test extends ic_base_test;
//  `uvm_component_utils (m32_s256_upsize_test) 
//  m32_s256_width_conv_vseq m32_s256_vseq;
//   
//  function new (string name = "m32_s256_upsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m32_s256_upsize_test main_phase", UVM_MEDIUM)
//    m32_s256_vseq = m32_s256_width_conv_vseq :: type_id :: create ("m32_s256_vseq");
//    phase.raise_objection (this);
//    m32_s256_vseq.start (vseqr);
//    repeat (9000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m32_s256_upsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m32_s256_upsize_test
//
//class m64_s128_upsize_test extends ic_base_test;
//  `uvm_component_utils (m64_s128_upsize_test) 
//  m64_s128_width_conv_vseq m64_s128_vseq;
//   
//  function new (string name = "m64_s128_upsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m64_s128_upsize_test main_phase", UVM_MEDIUM)
//    m64_s128_vseq = m64_s128_width_conv_vseq :: type_id :: create ("m64_s128_vseq");
//    phase.raise_objection (this);
//    m64_s128_vseq.start (vseqr);
//    repeat (15000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m64_s128_upsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m64_s128_upsize_test
//
//
//class m64_s256_upsize_test extends ic_base_test;
//  `uvm_component_utils (m64_s256_upsize_test) 
//  m64_s256_width_conv_vseq m64_s256_vseq;
//   
//  function new (string name = "m64_s256_upsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m64_s256_upsize_test main_phase", UVM_MEDIUM)
//    m64_s256_vseq = m64_s256_width_conv_vseq :: type_id :: create ("m64_s256_vseq");
//    phase.raise_objection (this);
//    m64_s256_vseq.start (vseqr);
//    repeat (9000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m64_s256_upsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m64_s256_upsize_test
//
//
//class m128_s256_upsize_test extends ic_base_test;
//  `uvm_component_utils (m128_s256_upsize_test) 
//  m128_s256_width_conv_vseq m128_s256_vseq;
//   
//  function new (string name = "m128_s256_upsize_test", uvm_component parent);
//    super.new (name, parent);
//  endfunction
//  task main_phase (uvm_phase phase);
//    `uvm_info (get_full_name(), "inside m128_s256_upsize_test main_phase", UVM_MEDIUM)
//    m128_s256_vseq = m128_s256_width_conv_vseq :: type_id :: create ("m128_s256_vseq");
//    phase.raise_objection (this);
//    m128_s256_vseq.start (vseqr);
//    repeat (20000) @ (posedge obj.mas_if[0].aclk);
//    phase.drop_objection (this);
//    `uvm_info (get_full_name(), "m128_s256_upsize_test main_phase ended", UVM_MEDIUM)
//  endtask
//endclass: m128_s256_upsize_test
//
//
///********************* DECODE ERROR TEST ***********************/
//class decode_error_test extends ic_base_test;
//  `uvm_component_utils (decode_error_test)
//  decode_error_vseq error_vseq;
//
//  function new (string name ="decode_error_test", uvm_component parent);
//    super.new(name,parent);
//  endfunction:new
//
//  task main_phase (uvm_phase phase);
//    `uvm_info(get_full_name(),"inside decode_error_test",UVM_MEDIUM)
//    error_vseq = decode_error_vseq :: type_id :: create("error_vseq");
//    phase.raise_objection (this);
//    error_vseq.start(vseqr);
//    repeat(2000) @(posedge obj.mas_if[0].aclk);
//    phase.drop_objection(this);
//    `uvm_info (get_full_name(), "decode_error_test main_phase ended", UVM_MEDIUM)
//    
//  endtask:main_phase
//endclass:decode_error_test
//
//
///******************* SPLIT TRANSACTION TEST ************************/
//class splti_transaction_test extends ic_base_test;
//  `uvm_component_utils (splti_transaction_test)
//  split_trans_vseq split_vseq;
//
//  function new (string name ="splti_transaction_test", uvm_component parent);
//    super.new(name,parent);
//  endfunction:new
//
//  task main_phase (uvm_phase phase);
//    `uvm_info(get_full_name(),"inside splti_transaction_test",UVM_MEDIUM)
//    split_vseq = split_trans_vseq :: type_id :: create("split_vseq");
//    phase.raise_objection (this);
//    split_vseq.start(vseqr);
//    repeat(3000) @(posedge obj.mas_if[0].aclk);
//    phase.drop_objection(this);
//    `uvm_info (get_full_name(), "splti_transaction_test main_phase ended", UVM_MEDIUM)
//    
//  endtask:main_phase
//endclass:splti_transaction_test
//
//
///*************************** Priority Test ****************************/
//class priority_test extends ic_base_test;
//  `uvm_component_utils (priority_test)
//  priority_vseq p_vseq;
//
//  function new (string name ="priority_test", uvm_component parent);
//    super.new(name,parent);
//  endfunction:new
//
//  task main_phase (uvm_phase phase);
//    `uvm_info(get_full_name(),"inside priority_test",UVM_MEDIUM)
//    p_vseq = priority_vseq :: type_id :: create("p_vseq");
//    phase.raise_objection (this);
//    p_vseq.start(vseqr);
//    repeat(2000) @(posedge obj.mas_if[0].aclk);
//    phase.drop_objection(this);
//    `uvm_info (get_full_name(), "priority_test main_phase ended", UVM_MEDIUM)
//    
//  endtask:main_phase
//endclass:priority_test
//
//
///******************* Random Test ********************/
//class random_test extends ic_base_test;
//  `uvm_component_utils (random_test)
//  random_test_vseq r_vseq;
//
//  function new (string name ="random_test", uvm_component parent);
//    super.new(name,parent);
//  endfunction:new
//
//  task main_phase (uvm_phase phase);
//    `uvm_info(get_full_name(),"inside random_test",UVM_MEDIUM)
//    r_vseq = random_test_vseq :: type_id :: create("r_vseq");
//    phase.raise_objection (this);
//    r_vseq.start(vseqr);
//    repeat(2000) @(posedge obj.mas_if[0].aclk);
//    phase.drop_objection(this);
//    `uvm_info (get_full_name(), "random_test main_phase ended", UVM_MEDIUM)
//    
//  endtask:main_phase
//endclass:random_test
//
//
///////////////////////////////////////////////////////////
//
//
//class out_of_range_address extends ic_base_test;
//  `uvm_component_utils (out_of_range_address)
//  out_of_range_address_vseq out_vseq;
//
//  function new (string name ="out_of_range_address", uvm_component parent);
//    super.new(name,parent);
//  endfunction:new
//
//  task main_phase (uvm_phase phase);
//    `uvm_info(get_full_name(),"inside out_of_range_address",UVM_MEDIUM)
//    out_vseq = out_of_range_address_vseq :: type_id :: create("out_vseq");
//    phase.raise_objection (this);
//    out_vseq.start(vseqr);
//    repeat(10000) @(posedge obj.mas_if[0].aclk);
//    phase.drop_objection(this);
//    `uvm_info (get_full_name(), "out_of_range_address main_phase ended", UVM_MEDIUM)
//    
//  endtask:main_phase
//endclass:out_of_range_address
