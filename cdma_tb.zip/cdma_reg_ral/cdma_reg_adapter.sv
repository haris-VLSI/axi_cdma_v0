class cdma_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(cdma_reg_adapter)

  function new(string name = "cdma_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 1;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    master_seq_item bus_item = master_seq_item::type_id::create("bus_item");
    `uvm_info("ADAPTER", $sformatf("reg2bus IN  addr=0x%0h data=0x%0h kind=%s", rw.addr, rw.data, rw.kind.name()), UVM_LOW)

    bus_item.bresp[0] = 'h0;
    bus_item.wdata   = new[1];
    bus_item.rdata   = new[1];
    //bus_item.wstrobe = new[1];
    bus_item.rresp   = new[1];

    bus_item.awaddr = 'h0;
    bus_item.araddr = 'h0;
    bus_item.wdata[0] = 'h0;
    //bus_item.wstrobe[0] = 'hf;

    if (rw.kind == UVM_WRITE) begin
      bus_item.operation = WRITE;
      bus_item.awaddr    = rw.addr;
      bus_item.wdata[0]  = rw.data;
      //bus_item.awlen   = 0;
      //bus_item.awburst = INCR;
      //bus_item.awsize  = 2;

      `uvm_info("adapter_write",$sformatf("reg2bus WRITE addr=0x%0h data=0x%0h strobe=%0b", rw.addr, rw.data), UVM_LOW);

    end else begin
      bus_item.operation = READ;
      bus_item.araddr    = rw.addr;

      //bus_item.arlen   = 0;
      //bus_item.arburst = INCR;
      //bus_item.arsize  = 2;

      `uvm_info("adapter_read",$sformatf("reg2bus READ addr=0x%0h", rw.addr), UVM_LOW);
    end
    `uvm_info("ADAPTER", $sformatf("reg2bus OUT awaddr=0x%0h araddr=0x%0h wdata=0x%0h",bus_item.awaddr, bus_item.araddr, bus_item.wdata[0]), UVM_LOW)
    return bus_item;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item,ref uvm_reg_bus_op rw);
    master_seq_item bus_pkt;
    if (!$cast(bus_pkt, bus_item))
      `uvm_fatal(get_type_name(), "Failed to cast bus_item transaction")
    rw.byte_en = 0;
    if (bus_pkt.operation == READ) begin
      rw.kind = UVM_READ;
      rw.addr = bus_pkt.araddr;
      rw.data = bus_pkt.rdata[0];
    end
    else begin
      rw.kind = UVM_WRITE;
      rw.addr = bus_pkt.awaddr;
      rw.data = bus_pkt.wdata[0];
    end
    rw.status  = UVM_IS_OK;
  endfunction
endclass



  //virtual function void bus2reg (uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
  //  master_seq_item bus_pkt;
  //  if(!$cast(bus_pkt, bus_item))
  //    `uvm_fatal(get_type_name(), "Failed to cast bus_item transaction")

  //  rw.addr = bus_pkt.araddr;
  //  rw.addr = bus_pkt.awaddr;
  //  rw.data = bus_pkt.rdata[0];
  //  rw.kind = (bus_pkt.operation) ? UVM_READ: UVM_WRITE;
  //endfunction

  //virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
  //  master_seq_item axi_item;
  //
  //  if (!($cast(axi_item, bus_item))) begin
  //    `uvm_fatal("ADAPTER_CAST", "Failed to cast bus_item to master_seq_item");
  //  end else begin
  //    rw.kind = (axi_item.operation == WRITE) ? UVM_WRITE : UVM_READ;
  //    if (rw.kind == UVM_READ) begin
  //      rw.addr = axi_item.araddr;
  //      if (axi_item.rdata.size() > 0) begin
  //        rw.data = axi_item.rdata[0];
  //      end else begin
  //        rw.data = 'h0;
  //        `uvm_error("ADAPTER_READ", "rdata array is empty!")
  //      end
  //      if (axi_item.rresp.size() > 0)
  //        rw.status = (axi_item.rresp[0] == 0) ? UVM_IS_OK : UVM_NOT_OK;
  //      else
  //        rw.status = UVM_NOT_OK;
  //      `uvm_info("ADAPTER_READ", $sformatf("bus2reg READ addr=0x%0h data=0x%0h status=%s", 
  //                rw.addr, rw.data, rw.status.name()), UVM_MEDIUM)
  //    end 
  //    else begin // WRITE
  //      rw.addr = axi_item.awaddr; 
  //      if (axi_item.wdata.size() > 0) rw.data = axi_item.wdata[0];
  //      else                          rw.data = 'h0;
  //      rw.status = (axi_item.bresp == 0) ? UVM_IS_OK : UVM_NOT_OK;
  //      `uvm_info("ADAPTER_WRITE", $sformatf("bus2reg WRITE addr=0x%0h status=%s", 
  //                rw.addr, rw.status.name()), UVM_MEDIUM)
  //    end
  //  end
  //endfunction


/*
class cdma_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(cdma_reg_adapter)
  
  function new(string name = "cdma_reg_adapter");
    super.new(name);
  endfunction
  
  virtual function uvm_sequence_item reg2bus (const ref uvm_reg_bus_op rw);
    master_seq_item bus_item = master_seq_item::type_id::create("bus_item");
    bus_item.awaddr = rw.addr;
    bus_item.araddr = rw.addr;
    bus_item.wdata[0] = rw.data;
    bus_item.operation = (rw.kind == UVM_READ) ? READ : WRITE;
    
    `uvm_info(get_type_name, $sformatf("reg2bus: addr = %0h, data = %0h, rd_or_wr = %0h", bus_item.awaddr, bus_item.wdata[0], bus_item.operation), UVM_LOW);
    return bus_item;
  endfunction
  
  virtual function void bus2reg (uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    master_seq_item bus_pkt;
    if(!$cast(bus_pkt, bus_item))
      `uvm_fatal(get_type_name(), "Failed to cast bus_item transaction")

    rw.addr = bus_pkt.araddr;
    rw.addr = bus_pkt.awaddr;
    rw.data = bus_pkt.rdata[0];
    rw.kind = (bus_pkt.operation) ? UVM_READ: UVM_WRITE;
  endfunction
endclass
*/

/*
class cdma_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(cdma_reg_adapter)

  function new(string name = "cdma_reg_adapter");
    super.new(name);
    supports_byte_enable = 0; 
    provides_responses   = 1; 
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    master_seq_item pkt = master_seq_item::type_id::create("pkt");

    if (rw.kind == UVM_READ) begin
      pkt.operation = READ;
      pkt.araddr    = rw.addr;
    end
    else begin
      pkt.operation = WRITE;
      pkt.awaddr    = rw.addr;
      pkt.wdata[0]  = rw.data; // AXI4-Lite registers are 32-bit
    end

    return pkt;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item,
                                ref uvm_reg_bus_op rw);
    master_seq_item pkt;
    if (!$cast(pkt, bus_item)) begin
      `uvm_fatal("ADAPTER", "Wrong bus item type: expected master_seq_item")
      return;
    end

    rw.status = (pkt.rresp[0] == OKAY) ? UVM_IS_OK : UVM_NOT_OK;

    if (pkt.operation == READ) begin
      rw.kind = UVM_READ;
      rw.addr = pkt.araddr;
      rw.data = pkt.rdata[0];
    end
    else begin
      rw.kind = UVM_WRITE;
      rw.addr = pkt.awaddr;
      rw.data = pkt.wdata[0];
    end
  endfunction

endclass
*/

/*
class cdma_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(cdma_reg_adapter)

  function new(string name = "cdma_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 1;
  endfunction

virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
  master_seq_item pkt = master_seq_item::type_id::create("pkt");

  if (rw.kind == UVM_READ) begin
    pkt.operation = READ;
    pkt.araddr    = rw.addr;
  end
  else begin
    pkt.operation = WRITE;
    pkt.awaddr    = rw.addr;
    pkt.wdata[0]  = rw.data;
  end

  return pkt;
endfunction

virtual function void bus2reg(uvm_sequence_item bus_item,
                              ref uvm_reg_bus_op rw);
  master_seq_item pkt;
  if (!$cast(pkt, bus_item)) begin
    `uvm_fatal("ADAPTER", "Wrong bus item type")
    return;
  end

  if (pkt.operation == READ) begin
    rw.kind = UVM_READ;
    rw.addr = pkt.araddr;
    rw.data = pkt.rdata[0];
  end
  else begin
    rw.kind = UVM_WRITE;
    rw.addr = pkt.awaddr;
    rw.data = pkt.wdata[0];
  end

  rw.status = UVM_IS_OK;
endfunction
endclass
*/

/*
class cdma_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(cdma_reg_adapter)

  function new(string name = "cdma_reg_adapter");
    super.new(name);
    supports_byte_enable = 0;
    provides_responses   = 1;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    master_seq_item pkt = master_seq_item::type_id::create("pkt");
    pkt.operation = (rw.kind == UVM_READ) ? READ : WRITE;
    pkt.awaddr = rw.addr;
    pkt.wdata[0] = rw.data;
    return pkt;
  endfunction: reg2bus

  virtual function void bus2reg(uvm_sequence_item bus_item,ref uvm_reg_bus_op rw);
    master_seq_item pkt;
    if (!$cast(pkt, bus_item)) begin
      `uvm_fatal("NOT_master_seq_item_TYPE","Provided bus_item not correct type")
      return;
    end
    rw.kind = pkt.operation ? UVM_WRITE : UVM_READ;
    rw.addr = pkt.araddr;
    rw.data = pkt.rdata[0];
    rw.status = UVM_IS_OK;
  endfunction: bus2reg

endclass
*/


/*
 class cdma_reg_adapter extends uvm_reg_adapter;
    `uvm_object_utils(cdma_reg_adapter)

    function new(string name = "cdma_reg_adapter");
        super.new(name);
        supports_byte_enable = 0;
        provides_responses   = 1;
    endfunction

    virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
        master_seq_item bus_item = master_seq_item::type_id::create("bus_item");

        bus_item.wdata = new[1];
        bus_item.rdata = new[1];
        bus_item.wstrobe = new[1];
        bus_item.rresp = new[1];
        bus_item.bresp = 'h0;
        
        if(rw.kind == UVM_WRITE)begin
            bus_item.operation = WRITE;
            bus_item.awaddr  = rw.addr;      
            bus_item.wdata = new[1];
            bus_item.wdata[0]   = rw.data;
            `uvm_info ("adapter_write", $sformatf ("reg2bus  rw data=0x%0h addr=0x%0h  kind=%s seq_item data=%p ",rw.data,rw.addr,rw.kind.name,bus_item.wdata), UVM_LOW)
        end
        else begin
            bus_item.operation = READ;
            bus_item.araddr = rw.addr;
            `uvm_info("adapter_read",$sformatf("reg2bus addr=0x%0h kind=%s",rw.addr,rw.kind.name), UVM_LOW)
        end
        return bus_item;
     endfunction

    //virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    //  master_seq_item bus_item = master_seq_item::type_id::create("bus_item");
    //  bus_item.awaddr = rw.addr;
    //  bus_item.araddr = rw.addr;

    //  bus_item.wdata = new[1];
    //  bus_item.wdata[0] = rw.data;
    //  bus_item.operation = (rw.kind == UVM_READ) ? READ : WRITE;
    //  return bus_item;
    //endfunction

    virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
        master_seq_item axi_item;

        if(!($cast(axi_item,bus_item)))begin
           `uvm_fatal("bus2reg fn cast","Failed to cast bus item transaction")
        end
        else begin
            rw.kind = (axi_item.operation==WRITE) ? UVM_WRITE : UVM_READ;
            if(rw.kind==UVM_WRITE)begin
                rw.addr=axi_item.awaddr;
                rw.data=axi_item.wdata[0];
                `uvm_info("adapter_write",$sformatf("bus2reg addr=0x%0h kind=%s",rw.addr,rw.kind.name), UVM_LOW)
             end
             else begin
                rw.addr=axi_item.araddr;
                rw.data=axi_item.rdata[0];
                `uvm_info ("adapter_read",$sformatf("bus2reg rw data=0x%0h addr=0x%0h kind=%s seq_item data=%p ",rw.data,rw.addr,rw.kind.name,axi_item.rdata), UVM_LOW)
            end
        end
    endfunction

    //virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    //  master_seq_item axi_item;
    //  if (!$cast(axi_item, bus_item)) begin
    //      `uvm_fatal("ADAPTER", "Cast_failed!")
    //      return;
    //  end
    //  //if (!$cast(axi_item, bus_item)) return;
    //  rw.addr = axi_item.araddr;

    //  if(axi_item.rdata.size() > 0)
    //      rw.data = axi_item.rdata[0];
    //  else
    //      rw.data = 0;
    //  rw.kind = (axi_item.operation == READ) ? UVM_READ : UVM_WRITE;
    //endfunction
endclass
*/
