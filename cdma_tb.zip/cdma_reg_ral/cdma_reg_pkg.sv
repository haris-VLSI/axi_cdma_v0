//package cdma_reg_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  //`include "cdmacr.sv"
  //`include "cdmasr.sv"
  //`include "curdesc_ptr.sv"
  //`include "curdesc_ptr_msb.sv"
  //`include "taildesc_ptr.sv"
  //`include "taildesc_ptr_msb.sv"
  //`include "sa.sv"
  //`include "sa_msb.sv"
  //`include "da.sv"
  //`include "da_msb.sv"
  //`include "btt.sv"
  //`include "cdma_reg_block.sv"
  `include "cdma_ral_model.sv"
  `include "cdma_reg_adapter.sv"
  `include "cdma_reg_predictor.sv"
//  `include "cdma_reg_env.sv"
//endpackage
