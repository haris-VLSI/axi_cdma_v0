class cdma_reg_predictor extends uvm_reg_predictor #(master_seq_item);
  `uvm_component_utils(cdma_reg_predictor)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction
endclass
