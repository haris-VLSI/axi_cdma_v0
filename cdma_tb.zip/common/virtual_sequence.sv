class virtual_sequence_base extends uvm_sequence;
   `uvm_object_utils(virtual_sequence_base)
   `uvm_declare_p_sequencer(virtual_sequencer)

   base_master_sequence m_seq;
   base_slave_sequence  s_seq;

   function new (string name = "virtual_sequence");
      super.new(name);
      m_seq   = base_master_sequence :: type_id :: create ("m_seq");
      s_seq   = base_slave_sequence  :: type_id :: create ("s_seq");
   endfunction

   task body ();
     `uvm_info(get_full_name(),"Invoking Sequnece start in V-sequence",UVM_LOW)
     fork
       s_seq.start(p_sequencer.s_seqr[0]);
     join_none
       m_seq.start(p_sequencer.m_seqr[0]);
   endtask : body
endclass : virtual_sequence_base

class reg_write_read_vseq extends virtual_sequence_base;
    `uvm_object_utils(reg_write_read_vseq)
    `uvm_declare_p_sequencer(virtual_sequencer)
    reg_write_read_seq w_r_seq;
    base_slave_sequence  s_seq;
 
    function new (string name = "reg_write_read_seq");
        super.new(name);
    endfunction

    task body();
    `uvm_info(get_full_name(),"Invoking Sequnece start in access_test_vseq",UVM_LOW)
    s_seq   = base_slave_sequence::type_id::create("s_seq");
    w_r_seq = reg_write_read_seq::type_id::create("w_r_seq");
        fork
            s_seq.start(p_sequencer.s_seqr[0]);
        join_none
        fork
            w_r_seq.start(p_sequencer.m_seqr[0]); 
        join
    endtask: body
endclass : reg_write_read_vseq

class simple_mode_wr_rd_vseq extends virtual_sequence_base;
    `uvm_object_utils(simple_mode_wr_rd_vseq)
 
    function new (string name = "simple_mode_wr_rd_vseq");
        super.new(name);
    endfunction

    `uvm_declare_p_sequencer(virtual_sequencer)

    simple_mode_wr_rd_seq master_seq;
    slave_memory_seq      mem_seq;

    task body();
        master_seq = simple_mode_wr_rd_seq::type_id::create("master_seq");
        mem_seq    = slave_memory_seq::type_id::create("mem_seq");
        fork
            mem_seq.start(p_sequencer.s_seqr[0]); 
        join_none 
        master_seq.model = p_sequencer.model; 
        master_seq.start(p_sequencer.m_seqr[0]);
    endtask
endclass















































































/* ************ access_test_vertual sequence ************* *
// single master to single slave
class m0_s0_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m0_s0_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m0_s0 acc_m0_s0;
  base_slave_sequence  s_seq0;
 
 function new (string name = "m0_s0_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info(get_full_name(),"Invoking Sequnece start in access_test_vseq",UVM_LOW)
   acc_m0_s0   = access_seq_m0_s0    :: type_id :: create("acc_m0_s0");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     acc_m0_s0.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: m0_s0_access_test_vseq

class m0_s1_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m0_s1_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m0_s1 acc_m0_s1;
  base_slave_sequence  s_seq1;
 
function new (string name = "m0_s1_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m0_s1   = access_seq_m0_s1    :: type_id :: create("acc_m0_s1");
   s_seq1      = base_slave_sequence :: type_id :: create("s0_seq0"); 
   fork
     s_seq1.start(p_sequencer.s_seqr[1]);
   join_none
   fork
     acc_m0_s1.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: m0_s1_access_test_vseq


class m0_s2_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m0_s2_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m0_s2 acc_m0_s2;
  base_slave_sequence  s_seq2;
 
function new (string name = "m0_s2_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m0_s2   = access_seq_m0_s2    :: type_id :: create("acc_m0_s2");
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   fork
     s_seq2.start(p_sequencer.s_seqr[2]);
   join_none
   fork
     acc_m0_s2.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: m0_s2_access_test_vseq

class m0_s3_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m0_s3_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m0_s3 acc_m0_s3;
  base_slave_sequence  s_seq3;
 
function new (string name = "m0_s3_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m0_s3   = access_seq_m0_s3    :: type_id :: create("acc_m0_s3");
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m0_s3.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: m0_s3_access_test_vseq

/* single_master_single_slave_access test:: m1 to s,0, s1, s2, s3 *
class m1_s0_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m1_s0_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m1_s0 acc_m1_s0;
  base_slave_sequence  s_seq0;
 
function new (string name = "m1_s0_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m1_s0   = access_seq_m1_s0    :: type_id :: create("acc_m1_s0");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     acc_m1_s0.start(p_sequencer.m_seqr[1]); 
   join
 endtask: body
endclass: m1_s0_access_test_vseq

class m1_s1_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m1_s1_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m1_s1 acc_m1_s1;
  base_slave_sequence  s_seq1;
 
function new (string name = "m1_s0_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m1_s1   = access_seq_m1_s1    :: type_id :: create("acc_m1_s1");
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   fork
     s_seq1.start(p_sequencer.s_seqr[1]);
   join_none
   fork
     acc_m1_s1.start(p_sequencer.m_seqr[1]); 
   join
 endtask: body
endclass: m1_s1_access_test_vseq

class m1_s2_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m1_s2_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m1_s2 acc_m1_s2;
  base_slave_sequence  s_seq2;
 
function new (string name = "m1_s2_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m1_s2   = access_seq_m1_s2    :: type_id :: create("acc_m1_s2");
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   fork
     s_seq2.start(p_sequencer.s_seqr[2]);
   join_none
   fork
     acc_m1_s2.start(p_sequencer.m_seqr[1]); 
   join
 endtask: body
endclass: m1_s2_access_test_vseq

class m1_s3_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m1_s3_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m1_s3 acc_m1_s3;
  base_slave_sequence  s_seq3;
 
function new (string name = "m1_s3_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m1_s3   = access_seq_m1_s3    :: type_id :: create("acc_m1_s3");
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m1_s3.start(p_sequencer.m_seqr[1]); 
   join
 endtask: body
endclass: m1_s3_access_test_vseq

/* single_master_single_slave_access test:: m2 to s,0, s1, s2, s3 */
/*
class m2_s0_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m2_s0_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m2_s0 acc_m2_s0;
  base_slave_sequence  s_seq0;
 
function new (string name = "m2_s0_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m2_s0   = access_seq_m2_s0    :: type_id :: create("acc_m2_s0");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     acc_m2_s0.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: m2_s0_access_test_vseq

class m2_s1_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m2_s1_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m2_s1 acc_m2_s1;
  base_slave_sequence  s_seq1;
 
function new (string name = "m2_s1_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m2_s1   = access_seq_m2_s1    :: type_id :: create("acc_m2_s1");
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   fork
     s_seq1.start(p_sequencer.s_seqr[1]);
   join_none
   fork
     acc_m2_s1.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: m2_s1_access_test_vseq

class m2_s2_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m2_s2_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m2_s2 acc_m2_s2;
  base_slave_sequence  s_seq2;
 
function new (string name = "m2_s2_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m2_s2   = access_seq_m2_s2    :: type_id :: create("acc_m2_s2");
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   fork
     s_seq2.start(p_sequencer.s_seqr[2]);
   join_none
   fork
     acc_m2_s2.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: m2_s2_access_test_vseq

class m2_s3_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m2_s3_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m2_s3 acc_m2_s3;
  base_slave_sequence  s_seq3;
 
function new (string name = "m2_s3_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m2_s3   = access_seq_m2_s3    :: type_id :: create("acc_m2_s3");
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m2_s3.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: m2_s3_access_test_vseq

/* single_master_single_slave_access test:: m3 to s,0, s1, s2, s3 *
class m3_s0_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m3_s0_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m3_s0 acc_m3_s0;
  base_slave_sequence  s_seq0;
 
function new (string name = "m3_s0_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m3_s0   = access_seq_m3_s0    :: type_id :: create("acc_m3_s0");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     acc_m3_s0.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: m3_s0_access_test_vseq

class m3_s1_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m3_s1_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m3_s1 acc_m3_s1;
  base_slave_sequence  s_seq1;
 
function new (string name = "m3_s1_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m3_s1   = access_seq_m3_s1    :: type_id :: create("acc_m3_s1");
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   fork
     s_seq1.start(p_sequencer.s_seqr[1]);
   join_none
   fork
     acc_m3_s1.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: m3_s1_access_test_vseq

class m3_s2_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m3_s2_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m3_s2 acc_m3_s2;
  base_slave_sequence  s_seq2;
 
function new (string name = "m3_s2_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m3_s2   = access_seq_m3_s2    :: type_id :: create("acc_m3_s2");
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   fork
     s_seq2.start(p_sequencer.s_seqr[2]);
   join_none
   fork
     acc_m3_s2.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: m3_s2_access_test_vseq

class m3_s3_access_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(m3_s3_access_test_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m3_s3 acc_m3_s3;
  base_slave_sequence  s_seq3;
 
function new (string name = "m2_s3_access_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m3_s3   = access_seq_m3_s3    :: type_id :: create("acc_m3_s3");
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m3_s3.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: m3_s3_access_test_vseq
//////////////////////////////////////////////////////////////////////////
class multi_master_multi_slave_access_vseq extends virtual_sequence_base;
  `uvm_object_utils(multi_master_multi_slave_access_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m0_s1 acc_m0_s1;
  access_seq_m0_s2 acc_m0_s2;
  access_seq_m1_s0 acc_m1_s0;
  access_seq_m1_s1 acc_m1_s1;
  access_seq_m2_s2 acc_m2_s2;
  access_seq_m2_s3 acc_m2_s3;
  access_seq_m3_s0 acc_m3_s0;
  access_seq_m3_s3 acc_m3_s3;
  base_slave_sequence  s_seq0;
  base_slave_sequence  s_seq1;
  base_slave_sequence  s_seq2;
  base_slave_sequence  s_seq3;
 
function new (string name = "multi_master_multi_slave_access_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in access_test_vseq" ,UVM_LOW)
   acc_m0_s1   = access_seq_m0_s1    :: type_id :: create("acc_m0_s1");
   acc_m0_s2   = access_seq_m0_s2    :: type_id :: create("acc_m0_s2");
   acc_m1_s0   = access_seq_m1_s0    :: type_id :: create("acc_m1_s0");
   acc_m1_s1   = access_seq_m1_s1    :: type_id :: create("acc_m1_s1");
   acc_m2_s2   = access_seq_m2_s2    :: type_id :: create("acc_m2_s2");
   acc_m2_s3   = access_seq_m2_s3    :: type_id :: create("acc_m2_s3");
   acc_m3_s0   = access_seq_m3_s0    :: type_id :: create("acc_m3_s0");
   acc_m3_s3   = access_seq_m3_s3    :: type_id :: create("acc_m3_s3");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
     s_seq1.start(p_sequencer.s_seqr[1]);
     s_seq2.start(p_sequencer.s_seqr[2]);
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m0_s1.start(p_sequencer.m_seqr[0]); 
     //acc_m0_s2.start(p_sequencer.m_seqr[0]); 
     acc_m1_s0.start(p_sequencer.m_seqr[1]); 
     //acc_m1_s1.start(p_sequencer.m_seqr[1]); 
     acc_m2_s2.start(p_sequencer.m_seqr[2]); 
     //acc_m2_s3.start(p_sequencer.m_seqr[2]); 
     //acc_m3_s3.start(p_sequencer.m_seqr[3]); 
     acc_m3_s0.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: multi_master_multi_slave_access_vseq

///////////////////////////////////////////////////////
class m64_s32_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m64_s32_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  m64_s32_downsize_seq m64_s32;
  base_slave_sequence  s_seq0;
 
function new (string name = "m64_s32_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   m64_s32   = m64_s32_downsize_seq    :: type_id :: create("m64_s32");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     m64_s32.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: m64_s32_width_conv_vseq

class m128_s32_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m128_s32_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  m128_s32_downsize_seq m128_s32;
  base_slave_sequence  s_seq0;
 
function new (string name = "m128_s32_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   m128_s32   = m128_s32_downsize_seq    :: type_id :: create("m128_s32");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     m128_s32.start(p_sequencer.m_seqr[1]); 
   join
 endtask: body
endclass: m128_s32_width_conv_vseq

class m256_s32_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m256_s32_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  m256_s32_downsize_seq m256_s32;
  base_slave_sequence  s_seq0;
 
function new (string name = "m256_s32_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   m256_s32   = m256_s32_downsize_seq    :: type_id :: create("m256_s32");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     m256_s32.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: m256_s32_width_conv_vseq

class m128_s64_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m128_s64_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  m128_s64_downsize_seq m128_s64;
  base_slave_sequence  s_seq1;
 
function new (string name = "m128_s64_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   m128_s64   = m128_s64_downsize_seq    :: type_id :: create("m128_s64");
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   fork
     s_seq1.start(p_sequencer.s_seqr[1]);
   join_none
   fork
     m128_s64.start(p_sequencer.m_seqr[1]); 
   join
 endtask: body
endclass: m128_s64_width_conv_vseq


class m256_s64_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m256_s64_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  m256_s64_downsize_seq m256_s64;
  base_slave_sequence  s_seq1;
 
function new (string name = "m256_s64_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   m256_s64   = m256_s64_downsize_seq    :: type_id :: create("m256_s64");
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   fork
     s_seq1.start(p_sequencer.s_seqr[1]);
   join_none
   fork
     m256_s64.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: m256_s64_width_conv_vseq

class m256_s128_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m256_s128_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  m256_s128_downsize_seq m256_s128;
  base_slave_sequence  s_seq2;
 
function new (string name = "m256_s128_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   m256_s128   = m256_s128_downsize_seq    :: type_id :: create("m256_s128");
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   fork
     s_seq2.start(p_sequencer.s_seqr[2]);
   join_none
   fork
     m256_s128.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: m256_s128_width_conv_vseq

//////////////////////////////////////////////////////////////////////////////
class m32_s64_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m32_s64_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m32_s64 acc_m32_s64;
  base_slave_sequence  s_seq1;
 
function new (string name = "m32_s64_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   acc_m32_s64   = access_seq_m32_s64    :: type_id :: create("acc_m32_s64");
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   fork
     s_seq1.start(p_sequencer.s_seqr[1]);
   join_none
   fork
     acc_m32_s64.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: m32_s64_width_conv_vseq

class m32_s128_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m32_s128_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m32_s128 acc_m32_s128;
  base_slave_sequence  s_seq2;
 
function new (string name = "m32_s128_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   acc_m32_s128   = access_seq_m32_s128    :: type_id :: create("acc_m32_s128");
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   fork
     s_seq2.start(p_sequencer.s_seqr[2]);
   join_none
   fork
     acc_m32_s128.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: m32_s128_width_conv_vseq

class m32_s256_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m32_s256_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m32_s256 acc_m32_s256;
  base_slave_sequence  s_seq3;
 
function new (string name = "m32_s256_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   acc_m32_s256   = access_seq_m32_s256    :: type_id :: create("acc_m32_s256");
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m32_s256.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: m32_s256_width_conv_vseq

class m64_s128_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m64_s128_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m64_s128 acc_m64_s128;
  base_slave_sequence  s_seq2;
 
function new (string name = "m64_s128_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   acc_m64_s128   = access_seq_m64_s128    :: type_id :: create("acc_m64_s128");
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   fork
     s_seq2.start(p_sequencer.s_seqr[2]);
   join_none
   fork
     acc_m64_s128.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: m64_s128_width_conv_vseq

class m64_s256_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m64_s256_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m64_s256 acc_m64_s256;
  base_slave_sequence  s_seq3;
 
function new (string name = "m64_s256_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   acc_m64_s256   = access_seq_m64_s256    :: type_id :: create("acc_m64_s256");
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m64_s256.start(p_sequencer.m_seqr[0]); 
   join
 endtask: body
endclass: m64_s256_width_conv_vseq

class m128_s256_width_conv_vseq extends virtual_sequence_base;
  `uvm_object_utils(m128_s256_width_conv_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  access_seq_m128_s256 acc_m128_s256;
  base_slave_sequence  s_seq3;
 
function new (string name = "m128_s256_width_conv_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   acc_m128_s256   = access_seq_m128_s256    :: type_id :: create("acc_m128_s256");
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     acc_m128_s256.start(p_sequencer.m_seqr[1]); 
   join
 endtask: body
endclass: m128_s256_width_conv_vseq


/*******************************DECODE ERROR TEST VSEQ************************************
class decode_error_vseq extends virtual_sequence_base;
  `uvm_object_utils(decode_error_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  decode_error_seq error_seq[4];
  base_slave_sequence  s_seq0, s_seq1, s_seq2,s_seq3;
 
function new (string name = "decode_error_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece decode_error_vseq" ,UVM_LOW)
   foreach(error_seq[i])begin
     error_seq[i]   = decode_error_seq    :: type_id :: create($sformatf("error_seq[%0d]",i));
   end
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   s_seq1      = base_slave_sequence :: type_id :: create("s_seq1"); 
   s_seq2      = base_slave_sequence :: type_id :: create("s_seq2"); 
   s_seq3      = base_slave_sequence :: type_id :: create("s_seq3"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
     s_seq1.start(p_sequencer.s_seqr[1]);
     s_seq2.start(p_sequencer.s_seqr[2]);
     s_seq3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     error_seq[0].start(p_sequencer.m_seqr[0]); 
     //error_seq[1].start(p_sequencer.m_seqr[1]); 
     //error_seq[2].start(p_sequencer.m_seqr[2]); 
     //eawsize == 3;rror_seq[3].start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass: decode_error_vseq



/***************** SPLIT TRANSACTION VSEQ *******************
class split_trans_vseq extends virtual_sequence_base;
  `uvm_object_utils(split_trans_vseq)
  `uvm_declare_p_sequencer (virtual_sequencer)
  
  split_trans_seq split_seq;
  base_slave_sequence s_seq1;

  function new (string name="split_trans_vseq");
    super.new();
  endfunction:new

  task body();
    split_seq = split_trans_seq :: type_id:: create("split_seq");
    s_seq1    = base_slave_sequence :: type_id :: create ("s_seq1");
    fork
      s_seq1.start(p_sequencer.s_seqr[0]);
    join_none
    fork
      split_seq.start(p_sequencer.m_seqr[0]);
    join
  endtask:body
endclass:split_trans_vseq




/******************* PRIORITY VSEQ**********************
class priority_vseq extends virtual_sequence_base;
  `uvm_object_utils(priority_vseq)
  `uvm_declare_p_sequencer (virtual_sequencer)

  access_seq_m0_s2 priority_seq_0;
  access_seq_m1_s2 priority_seq_1;
  access_seq_m2_s2 priority_seq_2;
  access_seq_m3_s2 priority_seq_3;
  base_slave_sequence  s_seq_0;
  base_slave_sequence  s_seq_1;
  base_slave_sequence  s_seq_2;
  base_slave_sequence  s_seq_3;
 
function new (string name = "priority_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece priority_vseq" ,UVM_LOW)
   priority_seq_0   = access_seq_m0_s2    :: type_id :: create("priority_seq_0");
   priority_seq_1   = access_seq_m1_s2    :: type_id :: create("priority_seq_1");
   priority_seq_2   = access_seq_m2_s2    :: type_id :: create("priority_seq_2");
   priority_seq_3   = access_seq_m3_s2    :: type_id :: create("priority_seq_3");
   
   s_seq_0     = base_slave_sequence :: type_id :: create("s_seq_0"); 
   s_seq_1     = base_slave_sequence :: type_id :: create("s_seq_1"); 
   s_seq_2     = base_slave_sequence :: type_id :: create("s_seq_2"); 
   s_seq_3     = base_slave_sequence :: type_id :: create("s_seq_3"); 
   fork
     s_seq_0.start(p_sequencer.s_seqr[0]);
     s_seq_1.start(p_sequencer.s_seqr[1]);
     s_seq_2.start(p_sequencer.s_seqr[2]);
     s_seq_3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     priority_seq_0.start(p_sequencer.m_seqr[0]); 
     priority_seq_1.start(p_sequencer.m_seqr[1]); 
     priority_seq_2.start(p_sequencer.m_seqr[2]); 
     priority_seq_3.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass:priority_vseq


class random_test_vseq extends virtual_sequence_base;
  `uvm_object_utils(random_test_vseq)
  `uvm_declare_p_sequencer (virtual_sequencer)

  random_test_seq random_seq_0;
  random_test_seq random_seq_1;
  random_test_seq random_seq_2;
  random_test_seq random_seq_3;
  base_slave_sequence s_seq_0;
  base_slave_sequence s_seq_1;
  base_slave_sequence s_seq_2;
  base_slave_sequence s_seq_3;
 
function new (string name = "random_test_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece random_test_vseq" ,UVM_LOW)
   random_seq_0   = random_test_seq    :: type_id :: create("random_seq_0");
   random_seq_1   = random_test_seq    :: type_id :: create("random_seq_1");
   random_seq_2   = random_test_seq    :: type_id :: create("random_seq_2");
   random_seq_3   = random_test_seq    :: type_id :: create("random_seq_3");
   
   s_seq_0     = base_slave_sequence :: type_id :: create("s_seq_0"); 
   s_seq_1     = base_slave_sequence :: type_id :: create("s_seq_1"); 
   s_seq_2     = base_slave_sequence :: type_id :: create("s_seq_2"); 
   s_seq_3     = base_slave_sequence :: type_id :: create("s_seq_3"); 
   fork
     s_seq_0.start(p_sequencer.s_seqr[0]);
     s_seq_1.start(p_sequencer.s_seqr[1]);
     s_seq_2.start(p_sequencer.s_seqr[2]);
     s_seq_3.start(p_sequencer.s_seqr[3]);
   join_none
   fork
     random_seq_0.start(p_sequencer.m_seqr[0]); 
     random_seq_1.start(p_sequencer.m_seqr[1]); 
     random_seq_2.start(p_sequencer.m_seqr[2]); 
     random_seq_3.start(p_sequencer.m_seqr[3]); 
   join
 endtask: body
endclass:random_test_vseq



//////////////////////////////////////////////////////
class out_of_range_address_vseq extends virtual_sequence_base;
  `uvm_object_utils(out_of_range_address_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)
  out_of_range_addr_downsize_seq m256_s32;
  base_slave_sequence  s_seq0;
 
function new (string name = "out_of_range_address_vseq");
    super.new(name);
 endfunction
 task body ();
   `uvm_info (get_full_name(), "Invoking Sequnece start in width conversion vseq" ,UVM_LOW)
   m256_s32   = out_of_range_addr_downsize_seq    :: type_id :: create("m256_s32");
   s_seq0      = base_slave_sequence :: type_id :: create("s_seq0"); 
   fork
     s_seq0.start(p_sequencer.s_seqr[0]);
   join_none
   fork
     m256_s32.start(p_sequencer.m_seqr[2]); 
   join
 endtask: body
endclass: out_of_range_address_vseq



