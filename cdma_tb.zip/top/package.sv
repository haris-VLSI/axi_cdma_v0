package axi_package;
 `include "uvm_macros.svh"
  import  uvm_pkg :: *;
// COMMON
 `include "../common/config_obj.sv"
 `include "../common/axi_parameters.sv"
 `include "../common/axi_base_sequence_item.sv"
 `include "../axi_lite/master_seq_item.sv"
 `include "../cdma_reg_ral/cdma_reg_pkg.sv"
 `include "../axi_lite/master_sequencer.sv"
 `include "../axi_lite/master_sequence.sv"
 //`include "../axi_slave/slave_mem.sv"
 `include "../axi_slave/slave_seq_item.sv"
 `include "../axi_slave/slave_sequencer.sv"
 `include "../axi_slave/slave_sequence.sv"
 `include "../axi_slave/slave_memory_seq.sv"
 //`include "../axi_lite/master_driver.sv"
 //`include "../axi_lite/master_monitor.sv"
 `include "../axi_lite/master_driver_1.sv"
 `include "../axi_lite/master_monitor_1.sv"
 `include "../axi_lite/master_agent.sv"
 //`include "../axi_slave/slave_driver.sv"
 //`include "../axi_slave/slave_monitor.sv"
 `include "../axi_slave/slave_driver_1.sv"
 `include "../axi_slave/slave_monitor_1.sv"
 `include "../axi_slave/slave_agent.sv"
// RAL
// TOP
 `include "../common/virtual_sequencer.sv"
 `include "../common/virtual_sequence.sv"
 `include "cdma_env.sv"  
 `include "ral_seq.sv"
 `include "cdma_base_test.sv"


//// function to decode slave_index from address
// function int decode_slave_index(input address_t address);
// automatic int slave_index = -1;
//    case(address[31:16]) //decode slave index
//    16'h44A0 : slave_index = 0;
//    16'h44A1 : slave_index = 1;
//    16'h44A2 : slave_index = 2;
//    16'h44A3 : slave_index = 3;
//    default  : `uvm_error("Scoreboard :: predict_slave_pkt","address_decoding_fail - unexpected_address")
//    endcase
//   return slave_index;
// endfunction
//
//// properties for assertions
//  property valid_handshake(logic clk,reset_n,valid,ready);
//  @(posedge clk) disable iff(!reset_n) valid && !(ready) |=> valid;
//  endproperty
//  property signal_stable(logic clk,reset_n,valid,ready, logic [255:0] signal);
//  @(posedge clk) disable iff(!reset_n) valid && !(ready) |=> $stable(signal);
//  endproperty

endpackage
